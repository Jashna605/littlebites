#!/usr/bin/env python3
"""Create a consistent SQLite backup and retain only the ten newest copies."""

import os
import sqlite3
from datetime import datetime
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(os.getenv("DB_PATH", str(ROOT / "littlebites.db")))
DESTINATION = ROOT / "backups"
RETAIN = 10


def backup_database(source=SOURCE, destination_dir=DESTINATION):
    source = Path(source)
    if not source.is_file():
        raise FileNotFoundError(f"Database not found: {source}")
    destination_dir = Path(destination_dir)
    destination_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().astimezone().strftime("%Y%m%d-%H%M%S-%f")
    target = destination_dir / f"littlebites-{timestamp}.db"
    src = sqlite3.connect(source, timeout=30)
    dst = sqlite3.connect(target)
    try:
        src.backup(dst)
        dst.commit()
    finally:
        dst.close()
        src.close()
    backups = sorted(destination_dir.glob("littlebites-*.db"), key=lambda item: item.stat().st_mtime, reverse=True)
    for old_backup in backups[RETAIN:]:
        old_backup.unlink()
    return target


if __name__ == "__main__":
    print(backup_database())
