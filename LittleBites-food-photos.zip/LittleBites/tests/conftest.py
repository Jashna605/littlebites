import os

os.environ.setdefault("SECRET_KEY", "test-only-secret-that-is-long-enough-for-littlebites")
os.environ.setdefault("FLASK_DEBUG", "1")
os.environ["ADMIN_USERNAME"] = ""
