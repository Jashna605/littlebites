import re

from app import create_app
from helpers import headers, post_json, signup, token


def payload(**updates):
    data = {
        "name": "Soft apple rice bowl", "from": 4, "time": "15 min",
        "ingredients": ["soft rice", "stewed apple"], "steps": ["Simmer until tender.", "Cool and serve."],
    }
    data.update(updates)
    return data


def test_guests_cannot_share_or_report_but_can_browse(tmp_path):
    client = create_app(str(tmp_path / "guest.db")).test_client()
    assert client.get("/api/recipes").status_code == 200
    assert post_json(client, "/api/recipes", payload()).status_code == 401
    assert post_json(client, "/api/recipes/1/report", {"reason": "Check"}).status_code == 401


def test_pending_recipe_is_visible_only_to_its_author_and_admin_can_approve(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "adminuser")
    app = create_app(str(tmp_path / "pending.db"))
    author = app.test_client()
    admin = app.test_client()
    guest = app.test_client()
    signup(admin, "adminuser")
    signup(author, "recipe_author")
    created = post_json(author, "/api/recipes", payload())
    recipe_id = created.get_json()["status"]
    assert created.status_code == 201 and recipe_id == "pending"
    recipes = author.get("/api/recipes").get_json()
    pending = next(item for item in recipes if item["n"] == "Soft apple rice bowl")
    assert pending["status"] == "pending"
    assert "author_user_id" not in pending
    assert all(item["n"] != "Soft apple rice bowl" for item in guest.get("/api/recipes").get_json())

    csrf = token(admin, "/admin")
    approved = admin.post(f"/admin/recipes/{pending['id']}/approve", data={"csrf_token": csrf})
    assert approved.status_code == 302
    assert any(item["id"] == pending["id"] for item in guest.get("/api/recipes").get_json())


def test_three_distinct_reports_auto_hide_and_admin_can_review(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "adminuser")
    app = create_app(str(tmp_path / "reported.db"))
    author = app.test_client()
    admin = app.test_client()
    signup(admin, "adminuser")
    signup(author, "author_one")
    created = post_json(author, "/api/recipes", payload())
    recipe = next(item for item in author.get("/api/recipes").get_json() if item["n"] == payload()["name"])
    csrf = token(admin, "/admin")
    admin.post(f"/admin/recipes/{recipe['id']}/approve", data={"csrf_token": csrf})
    guests = [app.test_client() for _ in range(3)]
    for index, client in enumerate(guests):
        signup(client, f"reporter_{index}")
        response = post_json(client, f"/api/recipes/{recipe['id']}/report", {"reason": f"Review {index}"})
        assert response.status_code == 201
    repeated = post_json(guests[0], f"/api/recipes/{recipe['id']}/report", {"reason": "Again"})
    assert repeated.status_code == 409
    public_recipes = guests[0].get("/api/recipes").get_json()
    assert all(item["id"] != recipe["id"] for item in public_recipes)
    report_page = admin.get("/admin")
    assert report_page.status_code == 200 and b"3 distinct reports" in report_page.data
    hidden = next(item for item in author.get("/api/recipes").get_json() if item["id"] == recipe["id"])
    assert hidden["status"] == "hidden"
    csrf = token(admin, "/admin")
    admin.post(f"/admin/recipes/{recipe['id']}/approve", data={"csrf_token": csrf})
    assert any(item["id"] == recipe["id"] for item in guests[0].get("/api/recipes").get_json())


def test_admin_can_reject_and_delete_pending_submissions(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "adminuser")
    app = create_app(str(tmp_path / "admin-actions.db"))
    admin, author = app.test_client(), app.test_client()
    signup(admin, "adminuser")
    signup(author, "author_one")
    rejected = post_json(author, "/api/recipes", payload(name="Reject this share"))
    rejected_id = next(item["id"] for item in author.get("/api/recipes").get_json() if item["n"] == "Reject this share")
    csrf = token(admin, "/admin")
    response = admin.post(f"/admin/recipes/{rejected_id}/reject", data={"csrf_token": csrf})
    assert response.status_code == 302
    assert all(item["id"] != rejected_id for item in author.get("/api/recipes").get_json())

    post_json(author, "/api/recipes", payload(name="Delete this share"))
    delete_id = next(item["id"] for item in author.get("/api/recipes").get_json() if item["n"] == "Delete this share")
    csrf = token(admin, "/admin")
    deleted = admin.post(f"/admin/recipes/{delete_id}/delete", data={"csrf_token": csrf})
    assert deleted.status_code == 302
    assert all(item["id"] != delete_id for item in author.get("/api/recipes").get_json())


def test_choking_risks_and_honey_are_rejected_for_young_community_recipes(tmp_path):
    client = create_app(str(tmp_path / "choking.db")).test_client()
    signup(client, "parent_food")
    assert post_json(client, "/api/recipes", payload(name="Grapes", **{"from": 1}, ingredients=["whole grapes"], steps=["Wash and serve."])).status_code == 400
    assert post_json(client, "/api/recipes", payload(name="Nuts", **{"from": 1}, ingredients=["whole nuts"], steps=["Serve."])).status_code == 400
    assert post_json(client, "/api/recipes", payload(name="Popcorn", **{"from": 1}, ingredients=["popcorn"], steps=["Pop kernels."])).status_code == 400
    assert post_json(client, "/api/recipes", payload(name="Carrots", **{"from": 1}, ingredients=["hard raw carrots"], steps=["Serve."])).status_code == 400
    assert post_json(client, "/api/recipes", payload(name="Hot dog pieces", **{"from": 1}, ingredients=["hot dog"], steps=["Cut into large chunks of hot dog."])).status_code == 400
    assert post_json(client, "/api/recipes", payload(name="Baby honey oats", **{"from": 1}, ingredients=["oats", "honey"], steps=["Stir together."])).status_code == 400
    safer = post_json(client, "/api/recipes", payload(name="Soft grape mash", **{"from": 1}, ingredients=["peeled, quartered grapes"], steps=["Mash until soft."]))
    assert safer.status_code == 201


def test_authors_can_delete_own_recipe_but_not_another_users(tmp_path):
    app = create_app(str(tmp_path / "owner-delete.db"))
    first, second = app.test_client(), app.test_client()
    signup(first, "first_author")
    signup(second, "second_author")
    created = post_json(first, "/api/recipes", payload(name="First share"))
    recipe = next(item for item in first.get("/api/recipes").get_json() if item["n"] == "First share")
    other_delete = second.delete(f"/api/recipes/{recipe['id']}", headers=headers(second, False))
    assert other_delete.status_code == 404
    assert first.delete(f"/api/recipes/{recipe['id']}", headers=headers(first, False)).status_code == 200


def test_reporting_has_a_per_user_rate_limit(tmp_path):
    app = create_app(str(tmp_path / "report-limit.db"))
    app.config["REPORT_RATE_LIMIT"] = (1, 60)
    author, reporter = app.test_client(), app.test_client()
    signup(author, "recipe_author")
    signup(reporter, "recipe_reporter")
    post_json(author, "/api/recipes", payload(name="First report target"))
    post_json(author, "/api/recipes", payload(name="Second report target"))
    recipes = author.get("/api/recipes").get_json()
    first = next(item for item in recipes if item["n"] == "First report target")
    second = next(item for item in recipes if item["n"] == "Second report target")
    assert post_json(reporter, f"/api/recipes/{first['id']}/report", {"reason": "Review"}).status_code == 201
    limited = post_json(reporter, f"/api/recipes/{second['id']}/report", {"reason": "Review"})
    assert limited.status_code == 429


def test_author_can_edit_own_recipe_and_approved_edit_returns_to_pending(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "adminuser")
    app = create_app(str(tmp_path / "community-edit.db"))
    admin, author, other = app.test_client(), app.test_client(), app.test_client()
    signup(admin, "adminuser")
    signup(author, "recipe_author")
    signup(other, "other_author")
    post_json(author, "/api/recipes", payload(name="Original family bowl"))
    recipe = next(item for item in author.get("/api/recipes").get_json() if item["n"] == "Original family bowl")
    assert recipe["can_edit"] is True

    csrf = token(admin, "/admin")
    assert admin.post(f"/admin/recipes/{recipe['id']}/approve", data={"csrf_token": csrf}).status_code == 302
    denied = other.put(f"/api/recipes/{recipe['id']}", json=payload(name="Other's edit"), headers=headers(other))
    assert denied.status_code == 404
    response = author.put(f"/api/recipes/{recipe['id']}", json=payload(name="Updated family bowl", meal="lunch"), headers=headers(author))
    assert response.status_code == 200
    updated = next(item for item in author.get("/api/recipes").get_json() if item["id"] == recipe["id"])
    assert updated["n"] == "Updated family bowl" and updated["meal"] == "lunch" and updated["status"] == "pending"
    assert updated["can_edit"] is True


def test_edit_reuses_create_validation_and_duplicate_checks(tmp_path):
    app = create_app(str(tmp_path / "edit-validation.db"))
    author = app.test_client()
    signup(author, "edit_author")
    post_json(author, "/api/recipes", payload(name="First soft bowl"))
    post_json(author, "/api/recipes", payload(name="Second soft bowl", ingredients=["rice", "peas"]))
    recipes = author.get("/api/recipes").get_json()
    first = next(item for item in recipes if item["n"] == "First soft bowl")
    second = next(item for item in recipes if item["n"] == "Second soft bowl")

    unsafe = author.put(f"/api/recipes/{first['id']}", json=payload(name="Unsafe edit", **{"from": 1}, ingredients=["whole grapes"]), headers=headers(author))
    assert unsafe.status_code == 400 and "choking" in unsafe.get_json()["error"].lower()
    too_long = author.put(f"/api/recipes/{first['id']}", json=payload(name="x" * 81), headers=headers(author))
    assert too_long.status_code == 400
    duplicate = author.put(f"/api/recipes/{first['id']}", json=payload(name="Second soft bowl", ingredients=["peas", "rice"]), headers=headers(author))
    assert duplicate.status_code == 409

    other = app.test_client()
    signup(other, "second_author")
    denied = other.put(f"/api/recipes/{first['id']}", json=payload(name="No access"), headers=headers(other))
    assert denied.status_code == 404


def test_admin_can_change_community_recipe_meal_and_age(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "adminuser")
    app = create_app(str(tmp_path / "admin-recipe-label.db"))
    admin, author = app.test_client(), app.test_client()
    signup(admin, "adminuser")
    signup(author, "recipe_author")
    post_json(author, "/api/recipes", payload(name="Admin label target"))
    recipe = next(item for item in author.get("/api/recipes").get_json() if item["n"] == "Admin label target")
    assert b"Community recipe details" in admin.get("/admin").data
    response = admin.post(f"/admin/recipes/{recipe['id']}/details", data={
        "csrf_token": token(admin, "/admin"), "from": "9", "meals": ["breakfast", "snack"],
    })
    assert response.status_code == 302
    updated = next(item for item in author.get("/api/recipes").get_json() if item["id"] == recipe["id"])
    assert updated["from"] == 9 and updated["meals"] == ["breakfast", "snack"]
