import json
import sqlite3
from io import BytesIO
from pathlib import Path

import app as app_module
from app import create_app
from db import all_recipes, init
from helpers import headers, post_json, signup


def test_app_starts_and_serves_seeded_recipes(tmp_path):
    app = create_app(str(tmp_path / "test.db"))
    client = app.test_client()

    page = client.get("/")
    recipes = client.get("/api/recipes")
    stylesheet = client.get("/static/styles.css")
    script = client.get("/static/app.js")

    assert page.status_code == 200
    assert b"Good food" in page.data
    assert b"Skip to content" in page.data
    assert b"aria-current=\"location\"" in page.data
    assert stylesheet.status_code == 200 and b"prefers-reduced-motion" in stylesheet.data
    assert script.status_code == 200 and b"/api/chat" in script.data
    assert recipes.status_code == 200
    assert len(recipes.get_json()) == 68
    assert all("tags" in recipe for recipe in recipes.get_json())
    assert all(recipe["photo"].endswith(".webp") for recipe in recipes.get_json())


def test_startup_backfills_new_starter_recipes_without_duplicates(tmp_path):
    path = tmp_path / "older.db"
    seed = json.loads((Path(__file__).parents[1] / "data" / "seed_recipes.json").read_text())
    con = sqlite3.connect(path)
    con.execute("""CREATE TABLE recipes(
        id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, from_age INTEGER NOT NULL,
        time TEXT DEFAULT '', ingredients TEXT NOT NULL, steps TEXT NOT NULL, note TEXT DEFAULT '',
        community INTEGER DEFAULT 0, created TEXT DEFAULT CURRENT_TIMESTAMP,
        meal TEXT NOT NULL DEFAULT 'dinner')""")
    for recipe in seed[:6]:
        con.execute(
            "INSERT INTO recipes(name,from_age,time,ingredients,steps,note,community) VALUES(?,?,?,?,?,?,0)",
            (recipe["n"], recipe["from"], recipe["time"], json.dumps(recipe["ing"]),
             json.dumps(recipe["steps"]), recipe.get("note", "")),
        )
    con.execute(
        "INSERT INTO recipes(name,from_age,ingredients,steps,note,community,meal) VALUES(?,?,?,?,?,1,'lunch')",
        ("Family soup", 4, json.dumps(["potato"]), json.dumps(["Simmer until soft."]), "Community"),
    )
    con.commit()
    con.close()

    init(str(path))
    first_load = all_recipes(str(path))
    init(str(path))
    second_load = all_recipes(str(path))

    assert len(first_load) == len(seed) + 1
    assert len(second_load) == len(first_load)
    assert sum(recipe["community"] for recipe in second_load) == 1
    family_soup = next(recipe for recipe in second_load if recipe["n"] == "Family soup")
    assert family_soup["meals"] == ["lunch"]
    assert family_soup["photo"] == ""
    first_starter = next(recipe for recipe in second_load if recipe["n"] == seed[0]["n"])
    assert first_starter["photo"] == "banana-oat-pancakes.webp"


def test_renamed_starter_recipe_is_matched_by_stable_seed_id(tmp_path):
    path = tmp_path / "renamed-seed.db"
    init(str(path))
    con = sqlite3.connect(path)
    con.execute("UPDATE recipes SET name = ? WHERE seed_id = ?", ("A parent-renamed recipe", "littlebites-seed-001"))
    con.commit()
    con.close()

    init(str(path))
    recipes = all_recipes(str(path))
    assert sum(recipe["n"] == "A parent-renamed recipe" for recipe in recipes) == 1
    assert len(recipes) == len(json.loads((Path(__file__).parents[1] / "data" / "seed_recipes.json").read_text()))


def test_recipe_api_rejects_bad_payloads_cleanly(tmp_path):
    client = create_app(str(tmp_path / "test.db")).test_client()
    signup(client)

    assert post_json(client, "/api/recipes", ["not", "an", "object"]).status_code == 400
    assert post_json(client, "/api/recipes", {"name": "Oops", "from": 1, "ingredients": "banana", "steps": ["mix"]}).status_code == 400
    assert post_json(client, "/api/recipes", {"name": "Oops", "from": True, "ingredients": ["banana"], "steps": ["mix"]}).status_code == 400


def test_valid_community_recipe_is_added(tmp_path):
    client = create_app(str(tmp_path / "test.db")).test_client()
    signup(client)
    response = post_json(client, "/api/recipes", {
        "name": "Apple oats", "from": 4,
        "ingredients": ["apple", "oats"], "steps": ["Mix and serve cool."]
    })

    assert response.status_code == 201 and response.get_json()["status"] == "pending"
    assert any(recipe["n"] == "Apple oats" for recipe in client.get("/api/recipes").get_json())
    latest = client.get("/api/recipes/new").get_json()
    assert latest[0]["n"] == "Apple oats"


def test_assistant_receives_recent_chat_history(tmp_path, monkeypatch):
    captured = {}

    def fake_ask(question, context, history):
        captured["question"] = question
        captured["history"] = history
        return "Try a soft lentil bowl."

    monkeypatch.setattr(app_module, "ask_llm", fake_ask)
    client = create_app(str(tmp_path / "test.db")).test_client()
    response = post_json(client, "/api/assistant", {
        "question": "Can I swap in rice?",
        "history": [
            {"role": "user", "content": "Suggest a lentil meal."},
            {"role": "assistant", "content": "Try a soft lentil bowl."},
        ],
    })

    assert response.status_code == 200
    assert captured["question"] == "Can I swap in rice?"
    assert len(captured["history"]) == 2


def test_meal_helper_uses_ollama_local_chat_api(monkeypatch):
    captured = {}

    def fake_urlopen(request, timeout):
        captured["url"] = request.full_url
        captured["timeout"] = timeout
        captured["payload"] = json.loads(request.data.decode("utf-8"))
        return BytesIO(json.dumps({"message": {"content": "Try a soft rice bowl."}}).encode("utf-8"))

    monkeypatch.setenv("OLLAMA_BASE_URL", "http://ollama.test:11434/")
    monkeypatch.setenv("OLLAMA_MODEL", "test-model")
    monkeypatch.setattr(app_module.urllib.request, "urlopen", fake_urlopen)
    reply = app_module.ask_llm("Suggest dinner", {"age":"4", "diet":"", "allergies":"", "pantry":"rice"}, [])

    assert captured["url"] == "http://ollama.test:11434/api/chat"
    assert captured["payload"]["model"] == "test-model"
    assert captured["payload"]["stream"] is False
    assert reply == "Try a soft rice bowl."


def test_assistant_rejects_non_object_payload(tmp_path):
    client = create_app(str(tmp_path / "test.db")).test_client()

    response = client.post("/api/assistant", data=json.dumps(["bad"]), headers=headers(client))

    assert response.status_code == 400




def test_recipe_pagination_server_filters_and_bounds(tmp_path):
    client = create_app(str(tmp_path / "pagination.db")).test_client()
    legacy = client.get("/api/recipes")
    assert isinstance(legacy.get_json(), list) and len(legacy.get_json()) == 68

    first = client.get("/api/recipes?page=1")
    data = first.get_json()
    assert set(data) == {"items", "total", "page", "pages"}
    assert len(data["items"]) == 24 and data["total"] == 68 and data["page"] == 1 and data["pages"] == 3
    page_two = client.get("/api/recipes?page=2&per_page=10&sort=age")
    assert page_two.get_json()["page"] == 2 and len(page_two.get_json()["items"]) == 10
    assert client.get("/api/recipes?page=1&per_page=60&age=0").get_json()["total"] == 11
    banana = client.get("/api/recipes?page=1&per_page=60&q=banana").get_json()
    assert banana["total"] > 0 and all("banana" in json.dumps(recipe).lower() for recipe in banana["items"])

    for query in ("page=0", "page=abc", "per_page=61", "per_page=0", "age=2", "age=old", "meal=brunch", "sort=unknown", "q=" + "x" * 101):
        assert client.get("/api/recipes?" + query).status_code == 400, query




def test_community_recipe_can_have_multiple_meals_and_snack_filter(tmp_path):
    client = create_app(str(tmp_path / "multi-meals.db")).test_client()
    signup(client)
    response = post_json(client, "/api/recipes", {
        "name": "Shared snack breakfast idea", "from": 4, "meals": ["breakfast", "snack"],
        "ingredients": ["banana", "oats"], "steps": ["Mash, mix, and cook until soft."],
    })
    assert response.status_code == 201
    recipe = next(item for item in client.get("/api/recipes").get_json() if item["n"] == "Shared snack breakfast idea")
    assert recipe["meals"] == ["breakfast", "snack"] and recipe["meal"] == "breakfast"
    snack = client.get("/api/recipes?page=1&per_page=60&meal=snack").get_json()
    assert any(item["id"] == recipe["id"] for item in snack["items"])
    assert b'data-meal-view="snack"' in client.get("/").data
    assert post_json(client, "/api/recipes", {
        "name": "Invalid meal list", "from": 4, "meals": [], "ingredients": ["pear"], "steps": ["Mash softly."],
    }).status_code == 400
