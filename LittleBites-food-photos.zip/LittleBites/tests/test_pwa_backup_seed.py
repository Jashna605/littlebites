import json
import sqlite3
from collections import Counter
from pathlib import Path

from app import create_app
from db import init
from scripts.backup import backup_database


ROOT = Path(__file__).parents[1]


def test_self_hosted_fonts_csp_and_pwa_shell(tmp_path):
    app = create_app(str(tmp_path / "pwa.db"))
    client = app.test_client()
    page = client.get("/")
    assert b"fonts.googleapis.com" not in page.data
    assert b'rel="manifest"' in page.data
    assert b"offline-notice" in page.data
    assert "default-src 'self'" in page.headers["Content-Security-Policy"]
    assert page.headers["X-Content-Type-Options"] == "nosniff"
    assert page.headers["X-Frame-Options"] == "DENY"
    assert page.headers["Referrer-Policy"] == "same-origin"

    manifest = json.loads(client.get("/static/manifest.webmanifest").data)
    assert manifest["display"] == "standalone"
    assert {icon["sizes"] for icon in manifest["icons"]} >= {"192x192", "512x512"}
    assert any(icon.get("purpose") == "maskable" for icon in manifest["icons"])
    assert client.get("/sw.js").headers["Service-Worker-Allowed"] == "/"
    assert b"api/account" in client.get("/static/sw.js").data
    for font in ("Fredoka-Variable.woff2", "Nunito-Variable.woff2"):
        assert (ROOT / "static" / "fonts" / font).read_bytes().startswith(b"wOF2")
    from PIL import Image
    for icon in ("icon-192.png", "icon-512.png", "maskable-512.png"):
        with Image.open(ROOT / "static" / "icons" / icon) as image:
            assert image.format == "PNG"


def test_seed_catalog_has_sixty_eight_complete_recipes_by_age(tmp_path):
    seeds = json.loads((ROOT / "data" / "seed_recipes.json").read_text())
    assert len(seeds) == 68
    assert Counter(recipe["from"] for recipe in seeds) == {0: 11, 1: 13, 4: 17, 9: 14, 13: 13}
    assert len({recipe["seed_id"] for recipe in seeds}) == 68
    for recipe in seeds:
        assert recipe["time"] and recipe["steps"] and recipe["note"]
        assert "texture" in recipe["note"].lower() or "choking" in recipe["note"].lower()
    babies = [recipe for recipe in seeds if recipe["from"] == 0]
    assert len(babies) == 11
    assert all("pediatrician" in recipe["note"].lower() for recipe in babies)
    assert all(not any("honey" in ingredient.lower() for ingredient in recipe["ing"]) for recipe in babies)
    assert sum("snack" in recipe["meals"] for recipe in seeds) >= 18
    assert sum(len(recipe["meals"]) > 1 for recipe in seeds[:60]) >= 10
    photos = {recipe["photo"] for recipe in seeds}
    assert len(photos) == 10
    for photo in photos:
        image_path = ROOT / "static" / "images" / photo
        assert image_path.read_bytes().startswith(b"RIFF")
    assert b"/static/images/banana-oat-pancakes.webp" in (ROOT / "static" / "sw.js").read_bytes()


def test_sqlite_uses_wal_and_backup_api_retains_ten(tmp_path):
    source = tmp_path / "littlebites.db"
    init(str(source))
    with sqlite3.connect(source) as con:
        assert con.execute("PRAGMA journal_mode").fetchone()[0].lower() == "wal"
        con.execute("CREATE TABLE backup_check(value TEXT)")
        con.execute("INSERT INTO backup_check VALUES('saved')")

    backup_dir = tmp_path / "backups"
    outputs = [backup_database(source, backup_dir) for _ in range(12)]
    saved = sorted(backup_dir.glob("littlebites-*.db"))
    assert len(saved) == 10
    with sqlite3.connect(saved[-1]) as con:
        assert con.execute("SELECT value FROM backup_check").fetchone()[0] == "saved"
