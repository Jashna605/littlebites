import safety


def tags(ingredient):
    return set(safety.tag([ingredient]))


def test_hidden_sources_and_common_allergen_edges():
    assert {"soy", "wheat"} <= tags("low-sodium soy sauce")
    assert "soy" in tags("tamari")
    assert "fish" in tags("Worcestershire sauce")
    assert "shellfish" in tags("oyster sauce")
    assert "tree nuts" in tags("pine nuts")
    assert "milk" in tags("ranch seasoning")


def test_oats_are_a_cross_contact_caution_not_gluten_free():
    result = tags("rolled oats")
    assert "may contain gluten" in result
    assert "gluten-free" not in result


def test_honey_has_infant_risk_flag():
    assert "honey: not safe under 12 months" in tags("honey")


def test_whole_word_matching_avoids_false_positives():
    assert "milk" not in tags("butternut squash")
    assert "milk" not in tags("peanut butter")
    assert "egg" not in tags("eggplant")
    assert "milk" not in tags("coconut cream")
    assert "coconut" in tags("coconut cream")
    assert "milk" not in tags("cream of tartar")
    assert "ham" not in tags("graham crackers")
    assert "ham" not in tags("chamomile tea")


def test_graham_crackers_are_not_mislabelled_gluten_or_dairy_free():
    result = tags("graham crackers")
    assert "wheat" in result
    assert "milk" in result
    assert "gluten-free" not in result
    assert "dairy-free" not in result


def test_plural_and_phrase_boundaries():
    assert "egg" in tags("2 eggs")
    assert "tree nuts" in tags("sliced almonds")
    assert "peanut" in tags("roasted peanuts")
    assert "egg" not in tags("eggplant, plantain")
    assert "ham" not in tags("graham flour")


def test_alt_milks_are_not_dairy_but_keep_their_own_allergen_tags():
    soy_milk = tags("soy milk")
    assert "soy" in soy_milk
    assert "milk" not in soy_milk
    assert "no listed animal ingredients found" in soy_milk
    assert "no listed dairy found" in soy_milk
    assert "tree nuts" in tags("almond milk")
    assert "milk" not in tags("almond milk")
    assert "milk" not in tags("oat milk")
    assert "may contain gluten" in tags("oat milk")


def test_chamomile_tea_is_plant_based_and_not_meat():
    result = tags("chamomile tea")
    assert "no listed meat or fish found" in result
    assert "no listed animal ingredients found" in result
    assert "ham" not in result


def test_free_from_phrases_do_not_trigger_the_negated_allergen():
    assert "peanut" not in tags("peanut-free granola")
    assert "wheat" not in tags("gluten free flour")
    assert "no listed gluten found" in tags("gluten free flour")


def test_worcestershire_and_ranch_seasoning_are_cautious_hidden_sources():
    assert "fish" in tags("Worcestershire sauce")
    assert "milk" in tags("ranch seasoning")
    assert "wheat" in tags("ranch seasoning")


def test_absence_tags_are_cautious_worded_clues():
    result = tags("apple and water")
    assert "no listed dairy found" in result
    assert "no listed gluten found" in result
    assert not {"vegan", "vegetarian", "dairy-free", "gluten-free"} & set(result)
