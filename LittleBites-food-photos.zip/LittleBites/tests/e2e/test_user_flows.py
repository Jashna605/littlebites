"""Optional browser coverage; install Playwright and Chromium to run these flows."""

from threading import Thread

import pytest
from werkzeug.serving import make_server

playwright_api = pytest.importorskip("playwright.sync_api", reason="Playwright is not installed")
from playwright.sync_api import Error as PlaywrightError, sync_playwright

from app import create_app


pytestmark = pytest.mark.e2e


@pytest.fixture(scope="session")
def browser():
    with sync_playwright() as playwright:
        try:
            instance = playwright.chromium.launch(headless=True)
        except PlaywrightError as error:
            pytest.skip(f"Playwright browser is not installed: {error}")
        yield instance
        instance.close()


@pytest.fixture
def server(tmp_path, monkeypatch):
    servers = []

    def start(admin_username=""):
        monkeypatch.setenv("ADMIN_USERNAME", admin_username)
        monkeypatch.setenv("MEAL_BUDDY_DEMO", "true")
        app = create_app(str(tmp_path / f"browser-{len(servers)}.db"))
        http_server = make_server("127.0.0.1", 0, app, threaded=True)
        thread = Thread(target=http_server.serve_forever, daemon=True)
        thread.start()
        servers.append((http_server, thread))
        return f"http://127.0.0.1:{http_server.server_port}"

    yield start
    for http_server, thread in servers:
        http_server.shutdown()
        thread.join(timeout=2)


def test_guest_meal_tabs_allergen_filter_recipe_detail_and_cooking(browser, server):
    page = browser.new_page(viewport={"width": 375, "height": 812})
    console_errors = []
    page.on("pageerror", lambda error: console_errors.append(str(error)))
    page.goto(server() + "/", wait_until="domcontentloaded")
    page.locator(".recipe-card").first.wait_for()
    assert page.get_by_role("link", name="Continue as guest").is_visible()

    page.locator('[data-meal-view="snack"]').click()
    page.get_by_text("Soft Pear Snack Purée", exact=True).wait_for()
    page.locator('[data-allergen="milk"]').click()
    page.wait_for_timeout(250)
    visible_cards = page.locator("#recipe-grid .recipe-card")
    for index in range(visible_cards.count()):
        assert visible_cards.nth(index).locator(".tag-alert").filter(has_text="Milk").count() == 0

    visible_cards.first.get_by_role("button", name="See recipe").click()
    page.locator("#recipe-dialog[open]").wait_for()
    assert page.locator("#dialog-ingredients li").count() > 0
    page.get_by_role("button", name="Start cooking").last.click()
    page.locator("#cooking-dialog[open]").wait_for()
    page.get_by_text("Step 1 of", exact=False).wait_for()
    page.keyboard.press("ArrowRight")
    page.get_by_text("Step 2 of", exact=False).wait_for()
    assert not console_errors
    page.close()


def test_signup_share_comment_post_and_admin_delete(browser, server):
    page = browser.new_page(viewport={"width": 1280, "height": 900})
    page.goto(server("e2e_parent") + "/signup", wait_until="domcontentloaded")
    page.get_by_label("Parent username").fill("e2e_parent")
    page.get_by_label("Password", exact=True).fill("family-password-123")
    page.get_by_label("Confirm password").fill("family-password-123")
    page.get_by_role("button", name="Create account").click()
    page.wait_for_url("**/")
    page.locator("#recipe-form").wait_for()

    page.locator("#recipe-name").fill("Browser test soft apple bowl")
    page.locator("#recipe-age").select_option("4")
    page.locator("#recipe-time").fill("8 min")
    page.locator("#recipe-ingredients").fill("apple\nplain yogurt")
    page.locator("#recipe-steps").fill("Mix the soft ingredients.\nServe cool.")
    page.get_by_role("button", name="Share recipe").click()
    page.get_by_text("Recipe submitted!", exact=False).wait_for()
    card = page.locator(".recipe-card").filter(has_text="Browser test soft apple bowl")
    card.get_by_role("button", name="See recipe").click()
    page.locator("#recipe-dialog[open]").wait_for()
    page.locator("#comment-input").fill("A friendly browser test comment")
    page.get_by_role("button", name="Post comment").click()
    page.get_by_text("A friendly browser test comment", exact=True).wait_for()

    page.goto(page.url.rstrip("/") + "/admin", wait_until="domcontentloaded")
    comment = page.locator(".admin-comment").filter(has_text="A friendly browser test comment")
    comment.wait_for()
    comment.get_by_role("button", name="Delete").click()
    page.get_by_text("A friendly browser test comment", exact=True).wait_for(state="detached")
    page.close()


def test_responsive_layout_has_no_horizontal_overflow(browser, server):
    page = browser.new_page(viewport={"width": 375, "height": 812})
    page.goto(server() + "/", wait_until="domcontentloaded")
    page.locator(".recipe-card").first.wait_for()
    for width in (375, 768, 1280):
        page.set_viewport_size({"width": width, "height": 900})
        assert page.evaluate("document.documentElement.scrollWidth <= window.innerWidth")
    assert not page.locator(".recipe-tab").first.is_hidden()
    page.close()
