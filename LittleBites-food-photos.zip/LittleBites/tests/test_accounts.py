import app as app_module
import db
from app import create_app
from helpers import post_json, signup, token
from werkzeug.middleware.proxy_fix import ProxyFix


def test_signup_hashes_password_and_username_is_case_insensitive(tmp_path):
    client = create_app(str(tmp_path / "users.db")).test_client()
    created = signup(client, "ParentCook", "correct-horse-8")
    assert created.status_code == 302
    assert "HttpOnly" in created.headers["Set-Cookie"]
    assert "SameSite=Lax" in created.headers["Set-Cookie"]
    user = db.user_by_username(str(tmp_path / "users.db"), "parentcook")
    assert user and user["password_hash"] != "correct-horse-8"
    assert user["password_hash"].startswith("scrypt:")

    csrf = token(client, "/signup")
    duplicate = client.post("/signup", data={
        "username": "parentcook", "password": "another-safe-password",
        "confirm_password": "another-safe-password", "csrf_token": csrf,
    })
    assert duplicate.status_code == 409


def test_password_minimum_and_generic_login_error(tmp_path):
    client = create_app(str(tmp_path / "login.db")).test_client()
    csrf = token(client, "/signup")
    short = client.post("/signup", data={
        "username": "parent1", "password": "short", "confirm_password": "short", "csrf_token": csrf,
    })
    assert short.status_code == 400
    signup(client, "parent1", "long-enough-password")

    client.post("/logout", data={"csrf_token": token(client, "/")})
    csrf = token(client, "/login")
    wrong = client.post("/login", data={"username": "parent1", "password": "bad-password", "csrf_token": csrf})
    assert wrong.status_code == 401
    page = client.get("/login")
    assert b"Wrong username or password" in page.data
    assert b"Username not found" not in page.data


def test_sign_up_can_be_closed_after_first_account(tmp_path, monkeypatch):
    monkeypatch.setenv("ALLOW_SIGNUP", "false")
    client = create_app(str(tmp_path / "closed.db")).test_client()
    assert signup(client, "firstparent").status_code == 302
    another = create_app(str(tmp_path / "closed.db")).test_client()
    assert another.get("/signup").status_code == 403
    csrf = token(another, "/")
    response = another.post("/signup", data={
        "username": "secondparent", "password": "safe-password-123", "confirm_password": "safe-password-123", "csrf_token": csrf,
    })
    assert response.status_code == 403


def test_first_account_uses_the_configured_admin_username(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "kitchenboss")
    client = create_app(str(tmp_path / "admin-bootstrap.db")).test_client()
    assert signup(client, "notadmin").status_code == 400
    assert db.user_count(str(tmp_path / "admin-bootstrap.db")) == 0
    assert signup(client, "kitchenboss").status_code == 302


def test_csrf_is_required_on_state_changing_api_and_logout(tmp_path):
    app = create_app(str(tmp_path / "csrf.db"))
    client = app.test_client()
    assert client.post("/api/recipes", json={}).status_code == 400
    signup(client)
    assert client.post("/api/account/favorites", json={"recipe_id": 1, "active": True}).status_code == 400
    csrf = token(client, "/")
    logout = client.post("/logout", data={"csrf_token": csrf})
    assert logout.status_code == 302
    assert client.get("/api/account/state").status_code == 401


def test_login_and_signup_attempts_are_limited_by_ip_and_username(tmp_path):
    app = create_app(str(tmp_path / "auth-limits.db"))
    app.config["LOGIN_RATE_LIMIT"] = (1, 60)
    app.config["SIGNUP_RATE_LIMIT"] = (1, 60)
    client = app.test_client()
    client.environ_base["REMOTE_ADDR"] = "192.0.2.10"
    csrf = token(client, "/login")
    form = {"username": "missing-user", "password": "wrong-password", "csrf_token": csrf}
    assert client.post("/login", data=form).status_code == 401
    same_username = app.test_client()
    same_username.environ_base["REMOTE_ADDR"] = "192.0.2.11"
    csrf = token(same_username, "/login")
    assert same_username.post("/login", data={**form, "csrf_token": csrf}).status_code == 429
    same_ip = app.test_client()
    same_ip.environ_base["REMOTE_ADDR"] = "192.0.2.10"
    csrf = token(same_ip, "/login")
    assert same_ip.post("/login", data={**form, "username": "another-user", "csrf_token": csrf}).status_code == 429

    signup_client = app.test_client()
    signup_client.environ_base["REMOTE_ADDR"] = "192.0.2.20"
    csrf = token(signup_client, "/signup")
    invalid = {"username": "x", "password": "short", "confirm_password": "short", "csrf_token": csrf}
    assert signup_client.post("/signup", data=invalid).status_code == 400
    same_signup_ip = app.test_client()
    same_signup_ip.environ_base["REMOTE_ADDR"] = "192.0.2.20"
    csrf = token(same_signup_ip, "/signup")
    assert same_signup_ip.post("/signup", data={**invalid, "username": "y", "csrf_token": csrf}).status_code == 429
    same_signup_name = app.test_client()
    same_signup_name.environ_base["REMOTE_ADDR"] = "192.0.2.21"
    csrf = token(same_signup_name, "/signup")
    assert same_signup_name.post("/signup", data={**invalid, "csrf_token": csrf}).status_code == 429


def test_secret_key_is_required_and_cookie_security_matches_debug(tmp_path, monkeypatch):
    monkeypatch.delenv("SECRET_KEY", raising=False)
    try:
        create_app(str(tmp_path / "no-secret.db"))
    except RuntimeError as error:
        assert "SECRET_KEY" in str(error)
    else:
        raise AssertionError("App must refuse to start without SECRET_KEY")

    monkeypatch.setenv("SECRET_KEY", "replace-with-a-private-random-value-long-enough-for-tests")
    try:
        create_app(str(tmp_path / "example-secret.db"))
    except RuntimeError as error:
        assert "SECRET_KEY" in str(error)
    else:
        raise AssertionError("App must refuse the example SECRET_KEY")

    monkeypatch.setenv("SECRET_KEY", "production-secret-key-with-more-than-32-characters")
    monkeypatch.setenv("FLASK_DEBUG", "false")
    secure_app = create_app(str(tmp_path / "secure.db"))
    assert secure_app.config["SESSION_COOKIE_HTTPONLY"] is True
    assert secure_app.config["SESSION_COOKIE_SAMESITE"] == "Lax"
    assert secure_app.config["SESSION_COOKIE_SECURE"] is True
    assert not isinstance(secure_app.wsgi_app, ProxyFix)
    monkeypatch.setenv("TRUST_PROXY", "true")
    trusted_app = create_app(str(tmp_path / "proxy.db"))
    assert isinstance(trusted_app.wsgi_app, ProxyFix)


def test_child_profiles_fill_chat_context_without_sending_child_name(tmp_path, monkeypatch):
    captured = {}
    def fake_ask(question, context, history):
        captured["context"] = context
        return "Try soft rice."
    monkeypatch.setattr(app_module, "ask_llm", fake_ask)
    client = create_app(str(tmp_path / "profiles.db")).test_client()
    signup(client)
    saved = post_json(client, "/api/profiles", {
        "name": "Little Sprout", "age": 4, "diet": "no listed dairy found", "allergens": ["milk", "peanut"],
    })
    assert saved.status_code == 200
    profile = saved.get_json()["profiles"][0]
    response = post_json(client, "/api/chat", {
        "message": "Suggest a soft dinner", "profile_id": profile["id"],
        "history": [], "age_range": "13 years", "allergies": "",
    })
    assert response.status_code == 200
    assert captured["context"] == {"age": "4 years", "diet": "no listed dairy found", "allergies": "milk, peanut", "pantry": ""}
    assert "Little Sprout" not in repr(captured)


def test_profile_allergens_are_used_in_server_chat_warning(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, "ask_llm", lambda *_: "Try a milk-based pudding.")
    client = create_app(str(tmp_path / "profile-warning.db")).test_client()
    signup(client)
    profile = post_json(client, "/api/profiles", {"name": "Kiddo", "age": 9, "allergens": ["milk"]}).get_json()["profiles"][0]
    response = post_json(client, "/api/chat", {"message": "Idea please", "profile_id": profile["id"]})
    assert "mentions milk" in response.get_json()["reply"]


def test_local_favorites_import_once_and_user_data_is_private(tmp_path):
    app = create_app(str(tmp_path / "sync.db"))
    first = app.test_client()
    signup(first, "first_parent")
    assert first.get("/api/account/state").get_json()["import_pending"] is True
    imported = post_json(first, "/api/account/import-local", {"favorites": [1, 2], "made": [3]})
    assert imported.status_code == 200
    state = first.get("/api/account/state").get_json()
    assert state["favorites"] == [1, 2] and state["made"] == [3]
    assert state["import_pending"] is False
    post_json(first, "/api/profiles", {"name": "Private nickname", "age": 4, "allergens": ["milk"]})
    assert post_json(first, "/api/account/import-local", {"favorites": [4], "made": []}).get_json()["already_done"] is True
    post_json(first, "/api/account/favorites", {"recipe_id": 1, "active": False})

    second = app.test_client()
    signup(second, "second_parent")
    other_state = second.get("/api/account/state").get_json()
    assert other_state["favorites"] == [] and other_state["made"] == []
    assert other_state["profiles"] == []


def test_made_recipe_can_be_marked_and_unmarked(tmp_path):
    client = create_app(str(tmp_path / "made-toggle.db")).test_client()
    signup(client)

    marked = post_json(client, "/api/account/made", {"recipe_id": 1, "active": True})
    assert marked.status_code == 200
    assert marked.get_json()["items"] == [1]
    assert client.get("/api/account/state").get_json()["made"] == [1]

    unmarked = post_json(client, "/api/account/made", {"recipe_id": 1, "active": False})
    assert unmarked.status_code == 200
    assert unmarked.get_json()["items"] == []
    assert client.get("/api/account/state").get_json()["made"] == []

    script = open("static/app.js", encoding="utf-8").read()
    assert "Made it ✓ (tap to undo)" in script
    assert "const total = state.made.size" in script


def test_password_change_requires_current_password_keeps_session_and_rotates_csrf(tmp_path):
    client = create_app(str(tmp_path / "password-change.db")).test_client()
    signup(client)
    old_token = token(client, "/account")
    wrong = client.post("/account/password", data={
        "csrf_token": old_token, "current_password": "wrong-password",
        "new_password": "new-password-123", "confirm_password": "new-password-123",
    })
    assert wrong.status_code == 400
    assert b"current password is incorrect" in client.get("/account").data.lower()

    old_token = token(client, "/account")
    changed = client.post("/account/password", data={
        "csrf_token": old_token, "current_password": "good-password-8",
        "new_password": "new-password-123", "confirm_password": "new-password-123",
    })
    assert changed.status_code == 302
    assert client.get("/api/account/state").status_code == 200
    assert token(client, "/account") != old_token

    client.post("/logout", data={"csrf_token": token(client, "/")})
    csrf = token(client, "/login")
    assert client.post("/login", data={"username": "parent_user", "password": "good-password-8", "csrf_token": csrf}).status_code == 401


def test_password_change_is_rate_limited_and_csrf_protected(tmp_path):
    app = create_app(str(tmp_path / "password-limit.db"))
    app.config["LOGIN_RATE_LIMIT"] = (1, 60)
    client = app.test_client()
    signup(client)
    assert client.post("/account/password", data={"current_password": "good-password-8"}).status_code == 400
    csrf = token(client, "/account")
    form = {"csrf_token": csrf, "current_password": "good-password-8", "new_password": "changed-password", "confirm_password": "changed-password"}
    assert client.post("/account/password", data=form).status_code == 302
    csrf = token(client, "/account")
    limited = client.post("/account/password", data={**form, "csrf_token": csrf, "current_password": "changed-password"})
    assert limited.status_code == 429


def test_delete_account_requires_password_confirmation_and_removes_user_data(tmp_path):
    path = str(tmp_path / "delete-account.db")
    client = create_app(path).test_client()
    signup(client)
    post_json(client, "/api/profiles", {"name": "Family nickname", "age": 4, "allergens": ["milk"]})
    post_json(client, "/api/account/favorites", {"recipe_id": 1, "active": True})
    post_json(client, "/api/account/made", {"recipe_id": 2, "active": True})
    post_json(client, "/api/recipes", {"name": "My family share", "from": 4, "ingredients": ["apple"], "steps": ["Cook softly."]})
    shared = next(item for item in client.get("/api/recipes").get_json() if item["n"] == "My family share")
    post_json(client, f"/api/recipes/{shared['id']}/comments", {"body": "Family comment"})

    csrf = token(client, "/account")
    wrong_password = client.post("/account/delete", data={"csrf_token": csrf, "password": "wrong-password", "confirmation": "DELETE"})
    assert wrong_password.status_code == 400 and db.user_count(path) == 1
    csrf = token(client, "/account")
    wrong_confirmation = client.post("/account/delete", data={"csrf_token": csrf, "password": "good-password-8", "confirmation": "delete"})
    assert wrong_confirmation.status_code == 400 and db.user_count(path) == 1

    csrf = token(client, "/account")
    deleted = client.post("/account/delete", data={"csrf_token": csrf, "password": "good-password-8", "confirmation": "DELETE"})
    assert deleted.status_code == 302
    assert db.user_count(path) == 0
    assert client.get("/api/account/state").status_code == 401
    assert not any(item["n"] == "My family share" for item in db.all_recipes(path))
    with db.connection(path) as con:
        assert con.execute("SELECT COUNT(*) FROM child_profiles").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM user_favorites").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM user_made").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM recipe_comments").fetchone()[0] == 0
        assert con.execute("SELECT COUNT(*) FROM comment_reports").fetchone()[0] == 0


def test_admin_account_cannot_be_deleted_and_has_no_delete_control(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "parent_user")
    client = create_app(str(tmp_path / "admin-delete.db")).test_client()
    signup(client)
    page = client.get("/account")
    assert b"Delete my account" not in page.data
    response = client.post("/account/delete", data={"csrf_token": token(client, "/account"), "password": "good-password-8", "confirmation": "DELETE"})
    assert response.status_code == 403
    assert db.user_count(str(tmp_path / "admin-delete.db")) == 1


def test_admin_reset_sets_one_time_password_and_requires_change_at_login(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "admin_user")
    path = str(tmp_path / "reset-password.db")
    app = create_app(path)
    admin, user = app.test_client(), app.test_client()
    signup(admin, "admin_user")
    signup(user, "family_user")
    user_id = db.user_by_username(path, "family_user")["id"]
    csrf = token(admin, "/admin")
    reset = admin.post(f"/admin/users/{user_id}/reset-password", data={"csrf_token": csrf})
    page = admin.get("/admin")
    import re
    match = re.search(rb"One-time temporary password for family_user: ([A-Za-z0-9_-]+)", page.data)
    assert reset.status_code == 302 and match
    temporary = match.group(1).decode()
    assert b"One-time temporary password" not in admin.get("/admin").data

    user.post("/logout", data={"csrf_token": token(user, "/")})
    csrf = token(user, "/login")
    login = user.post("/login", data={"username": "family_user", "password": temporary, "csrf_token": csrf})
    assert login.status_code == 302 and "/account" in login.headers["Location"]
    assert user.get("/account").status_code == 200
    csrf = token(user, "/account")
    changed = user.post("/account/password", data={"csrf_token": csrf, "current_password": temporary, "new_password": "fresh-family-password", "confirm_password": "fresh-family-password"})
    assert changed.status_code == 302
    assert db.user_by_username(path, "family_user")["must_change_password"] == 0
