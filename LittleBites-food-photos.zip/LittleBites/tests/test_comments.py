from app import create_app
from helpers import headers, post_json, signup, token


def recipe_payload(name="Comment test recipe"):
    return {"name": name, "from": 4, "meal": "lunch", "ingredients": ["soft rice"], "steps": ["Cook until tender."]}


def create_recipe(client, name="Comment test recipe"):
    post_json(client, "/api/recipes", recipe_payload(name))
    return next(item for item in client.get("/api/recipes").get_json() if item["n"] == name)


def approve(admin, recipe_id):
    return admin.post(f"/admin/recipes/{recipe_id}/approve", data={"csrf_token": token(admin, "/admin")})


def test_comment_edit_reply_depth_and_length_validation(tmp_path):
    client = create_app(str(tmp_path / "comment-edit.db")).test_client()
    signup(client, "comment_author")
    recipe = create_recipe(client)

    too_long = post_json(client, f"/api/recipes/{recipe['id']}/comments", {"body": "x" * 501})
    assert too_long.status_code == 400
    created = post_json(client, f"/api/recipes/{recipe['id']}/comments", {"body": "A helpful first note"})
    assert created.status_code == 201
    comment_id = created.get_json()["id"]
    edited = client.put(f"/api/comments/{comment_id}", json={"body": "Updated note"}, headers=headers(client))
    assert edited.status_code == 200
    comments = client.get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"]
    assert comments[0]["body"] == "Updated note" and comments[0]["edited_at"] and comments[0]["can_edit"]

    reply = post_json(client, f"/api/recipes/{recipe['id']}/comments", {"body": "A reply", "parent_id": comment_id})
    assert reply.status_code == 201
    nested = post_json(client, f"/api/recipes/{recipe['id']}/comments", {"body": "Too deep", "parent_id": reply.get_json()["id"]})
    assert nested.status_code == 400


def test_comment_permissions_and_pending_recipe_privacy(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "admin_user")
    app = create_app(str(tmp_path / "comment-private.db"))
    admin, author, other = app.test_client(), app.test_client(), app.test_client()
    signup(admin, "admin_user")
    signup(author, "recipe_author")
    signup(other, "other_user")
    recipe = create_recipe(author, "Private comments")
    comment = post_json(author, f"/api/recipes/{recipe['id']}/comments", {"body": "Only author and admin for now"})
    assert comment.status_code == 201
    assert other.get(f"/api/recipes/{recipe['id']}/comments").status_code == 403
    assert post_json(other, f"/api/recipes/{recipe['id']}/comments", {"body": "Not yet"}).status_code == 403
    assert admin.get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"][0]["body"] == "Only author and admin for now"

    approve(admin, recipe["id"])
    assert len(other.get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"]) == 1
    comment_id = comment.get_json()["id"]
    denied_edit = other.put(f"/api/comments/{comment_id}", json={"body": "Not mine"}, headers=headers(other))
    assert denied_edit.status_code == 403
    denied_without_csrf = author.put(f"/api/comments/{comment_id}", json={"body": "No token"})
    assert denied_without_csrf.status_code == 400


def test_three_distinct_reports_hide_comment_and_admin_can_restore_or_delete(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "admin_user")
    app = create_app(str(tmp_path / "comment-reports.db"))
    admin, author = app.test_client(), app.test_client()
    signup(admin, "admin_user")
    signup(author, "recipe_author")
    recipe = create_recipe(author, "Reported comment recipe")
    approve(admin, recipe["id"])
    comment_id = post_json(author, f"/api/recipes/{recipe['id']}/comments", {"body": "A reportable note"}).get_json()["id"]
    assert post_json(author, f"/api/comments/{comment_id}/report", {}).status_code == 409

    reporters = []
    for index in range(3):
        reporter = app.test_client()
        signup(reporter, f"reporter_{index}")
        reporters.append(reporter)
        response = post_json(reporter, f"/api/comments/{comment_id}/report", {"reason": "Please review"})
        assert response.status_code == 201
        if index == 0:
            assert post_json(reporter, f"/api/comments/{comment_id}/report", {}).status_code == 409

    assert all(item["id"] != comment_id for item in reporters[0].get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"])
    admin_view = admin.get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"]
    assert admin_view[0]["hidden"] is True
    page = admin.get("/admin")
    assert b"A reportable note" in page.data and b"Comments" in page.data
    restored = admin.post(f"/admin/comments/{comment_id}/restore", data={"csrf_token": token(admin, "/admin")})
    assert restored.status_code == 302
    assert any(item["id"] == comment_id for item in reporters[0].get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"])
    deleted = admin.post(f"/admin/comments/{comment_id}/delete", data={"csrf_token": token(admin, "/admin")})
    assert deleted.status_code == 302
    assert not reporters[0].get(f"/api/recipes/{recipe['id']}/comments").get_json()["comments"]


def test_comment_reporting_rate_limit_and_admin_only_moderation(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "admin_user")
    app = create_app(str(tmp_path / "comment-limit.db"))
    app.config["COMMENT_RATE_LIMIT"] = (1, 60)
    admin, author, reporter = app.test_client(), app.test_client(), app.test_client()
    signup(admin, "admin_user")
    signup(author, "recipe_author")
    signup(reporter, "comment_reporter")
    recipe = create_recipe(author, "Comment limit recipe")
    approve(admin, recipe["id"])
    first_id = post_json(author, f"/api/recipes/{recipe['id']}/comments", {"body": "First comment"}).get_json()["id"]
    # Use an admin-created second commenter so the target remains reportable by this account.
    second = app.test_client()
    signup(second, "second_author")
    second_id = post_json(second, f"/api/recipes/{recipe['id']}/comments", {"body": "Second comment"}).get_json()["id"]
    assert post_json(reporter, f"/api/comments/{first_id}/report", {}).status_code == 201
    limited = post_json(reporter, f"/api/comments/{second_id}/report", {})
    assert limited.status_code == 429 and int(limited.headers["Retry-After"]) >= 1

    non_admin = app.test_client()
    signup(non_admin, "not_admin")
    denied = non_admin.post(f"/admin/comments/{first_id}/delete", data={"csrf_token": token(non_admin, "/")})
    assert denied.status_code == 403
