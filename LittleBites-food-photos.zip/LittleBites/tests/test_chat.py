import app as app_module
from app import create_app
from helpers import post_json


def test_chat_rejects_empty_message(tmp_path):
    client = create_app(str(tmp_path / "chat-empty.db")).test_client()

    response = post_json(client, "/api/chat", {"message": "   "})

    assert response.status_code == 400
    assert "message" in response.get_json()["error"].lower()


def test_chat_uses_only_the_last_ten_history_messages(tmp_path, monkeypatch):
    captured = {}

    def fake_ask(question, context, history):
        captured["question"] = question
        captured["context"] = context
        captured["history"] = history
        return "Try a soft rice bowl, and check its texture."

    monkeypatch.setattr(app_module, "ask_llm", fake_ask)
    client = create_app(str(tmp_path / "chat-history.db")).test_client()
    history = [
        {"role": "user" if index % 2 == 0 else "assistant", "content": f"Message {index}"}
        for index in range(12)
    ]

    response = post_json(client, "/api/chat", {
        "message": "Can you make that simpler?",
        "history": history,
        "age_range": "4 years",
        "diet": "vegetarian",
        "allergies": "milk",
        "pantry": "rice, peas",
    })

    assert response.status_code == 200
    assert len(captured["history"]) == 10
    assert captured["history"][0]["content"] == "Message 2"
    assert captured["history"][-1]["content"] == "Message 11"
    assert captured["context"] == {"age": "4 years", "diet": "vegetarian", "allergies": "milk", "pantry": "rice, peas"}


def test_chat_demo_mode_needs_no_api_key_or_ollama(tmp_path, monkeypatch):
    monkeypatch.delenv("OPENAI_API_KEY", raising=False)
    monkeypatch.setenv("MEAL_BUDDY_DEMO", "true")

    def no_network(*_args, **_kwargs):
        raise AssertionError("Demo mode should not call a remote or local model")

    monkeypatch.setattr(app_module.urllib.request, "urlopen", no_network)
    client = create_app(str(tmp_path / "chat-demo.db")).test_client()

    response = post_json(client, "/api/chat", {"message": "Give me an idea"})

    assert response.status_code == 200
    assert "Demo mode is on" in response.get_json()["reply"]
