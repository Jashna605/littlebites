import re


def token(client, path="/"):
    response = client.get(path)
    match = re.search(rb'name="csrf-token" content="([^"]+)"', response.data)
    if not match:
        match = re.search(rb'name="csrf_token" value="([^"]+)"', response.data)
    assert match, response.data[:500]
    return match.group(1).decode()


def signup(client, username="parent_user", password="good-password-8"):
    csrf = token(client, "/signup")
    return client.post("/signup", data={
        "username": username, "password": password, "confirm_password": password, "csrf_token": csrf,
    })


def headers(client, json_body=True):
    result = {"X-CSRF-Token": token(client)}
    if json_body:
        result["Content-Type"] = "application/json"
    return result


def post_json(client, path, payload):
    return client.post(path, json=payload, headers=headers(client))


def delete(client, path):
    return client.delete(path, headers=headers(client, False))
