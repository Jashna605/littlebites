import json

import app as app_module
from app import create_app
from helpers import delete, headers, post_json, signup, token


def recipe_payload(**overrides):
    payload = {
        "name": "A bright apple bowl",
        "from": 4,
        "time": "12 min",
        "ingredients": ["apple", "plain yogurt"],
        "steps": ["Grate the apple.", "Stir it into the yogurt."],
    }
    payload.update(overrides)
    return payload


def test_assistant_allergy_check_expands_synonyms_and_plurals(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, "ask_llm", lambda *_: "Try peanut butter with milk.")
    client = create_app(str(tmp_path / "assistant.db")).test_client()

    response = post_json(client, "/api/assistant", {
        "question": "What can we eat?", "allergies": "nuts, dairy"
    })

    assert response.status_code == 200
    assert "mentions nuts, dairy" in response.get_json()["reply"]
    assert "Safety check" in response.get_json()["reply"]


def test_recipe_length_limits_and_time_validation(tmp_path):
    client = create_app(str(tmp_path / "lengths.db")).test_client()
    signup(client)
    assert post_json(client, "/api/recipes", recipe_payload(name="a" * 80)).status_code == 201

    assert post_json(client, "/api/recipes", recipe_payload(name="b" * 81)).status_code == 400
    assert post_json(client, "/api/recipes", recipe_payload(name="too many ingredients", ingredients=["x"] * 31)).status_code == 400
    assert post_json(client, "/api/recipes", recipe_payload(name="too many steps", steps=["x"] * 21)).status_code == 400
    assert post_json(client, "/api/recipes", recipe_payload(name="max list sizes", ingredients=["x"] * 30, steps=["x"] * 20)).status_code == 201
    assert post_json(client, "/api/recipes", recipe_payload(name="bad time", time="whenever")).status_code == 400


def test_new_recipes_api_is_capped_at_six(tmp_path):
    client = create_app(str(tmp_path / "recent.db")).test_client()
    assert len(client.get("/api/recipes/new").get_json()) == 6


def test_duplicate_community_recipe_is_rejected_case_and_order_insensitively(tmp_path):
    client = create_app(str(tmp_path / "duplicates.db")).test_client()
    signup(client)
    assert post_json(client, "/api/recipes", recipe_payload()).status_code == 201
    duplicate = recipe_payload(name="  A BRIGHT APPLE BOWL ", ingredients=["PLAIN yogurt", "apple"])
    response = post_json(client, "/api/recipes", duplicate)
    assert response.status_code == 409


def test_rate_limits_can_be_configured_and_return_retry_after(tmp_path):
    app = create_app(str(tmp_path / "limits.db"))
    app.config["RECIPE_RATE_LIMIT"] = (1, 60)
    client = app.test_client()
    signup(client)
    assert post_json(client, "/api/recipes", {}).status_code == 400
    limited = post_json(client, "/api/recipes", {})
    assert limited.status_code == 429
    assert int(limited.headers["Retry-After"]) >= 1


def test_assistant_has_its_own_rate_limit(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, "ask_llm", lambda *_: "A gentle rice bowl could work.")
    app = create_app(str(tmp_path / "assistant-limits.db"))
    app.config["ASSISTANT_RATE_LIMIT"] = (1, 60)
    client = app.test_client()
    payload = {"question": "Suggest a meal"}
    assert post_json(client, "/api/assistant", payload).status_code == 200
    assert post_json(client, "/api/assistant", payload).status_code == 429


def test_community_recipe_report_and_admin_delete(tmp_path, monkeypatch):
    client = create_app(str(tmp_path / "moderation.db")).test_client()
    signup(client)
    created = post_json(client, "/api/recipes", recipe_payload())
    assert created.status_code == 201
    community = next(r for r in client.get("/api/recipes").get_json() if r["n"] == "A bright apple bowl")

    report = post_json(client, f"/api/recipes/{community['id']}/report", {"reason": "Needs a safety review"})
    assert report.status_code == 201
    assert delete(client, f"/api/recipes/{community['id']}").status_code == 200
    deleted = delete(client, f"/api/recipes/{community['id']}")
    assert deleted.status_code == 404
    assert all(r["id"] != community["id"] for r in client.get("/api/recipes").get_json())


def test_json_error_handlers_and_health_endpoint(tmp_path):
    app = create_app(str(tmp_path / "errors.db"))
    app.config["MAX_CONTENT_LENGTH"] = 100

    @app.get("/_test_boom")
    def test_boom():
        raise RuntimeError("internal detail should not be returned")

    client = app.test_client()
    missing = client.get("/does-not-exist")
    too_large = client.post("/api/chat", data="x" * 300, headers=headers(client))
    broken = client.get("/_test_boom")

    assert missing.status_code == 404 and missing.is_json
    assert too_large.status_code == 413 and too_large.is_json
    assert broken.status_code == 500 and broken.is_json
    assert "internal detail" not in json.dumps(broken.get_json())
    assert client.get("/health").get_json() == {"status": "ok"}


def test_browser_errors_are_html_while_api_errors_stay_json(tmp_path, monkeypatch):
    monkeypatch.setenv("ADMIN_USERNAME", "admin_user")
    app = create_app(str(tmp_path / "html-errors.db"))

    @app.get("/_test_html_boom")
    def html_boom():
        raise RuntimeError("internal details stay private")

    @app.post("/_test_large")
    def large_page():
        return app_module.request.get_data()

    bootstrap_admin = app.test_client()
    signup(bootstrap_admin, "admin_user")
    adminish = app.test_client()
    signup(adminish, "not_admin")
    assert adminish.get("/api/account/state").status_code == 200
    app.config["MAX_CONTENT_LENGTH"] = 100
    browser = {"Accept": "text/html"}
    not_found = adminish.get("/unknown-page", headers=browser)
    forbidden = adminish.get("/admin", headers=browser)
    bad_csrf = adminish.post("/logout", headers=browser)
    large = adminish.post("/_test_large", data="x" * 300, headers={**headers(adminish, False), **browser})
    broken = adminish.get("/_test_html_boom", headers=browser)
    api_missing = adminish.get("/api/not-a-route", headers=browser)

    assert not_found.status_code == 404 and b"Back to LittleBites" in not_found.data and not_found.mimetype == "text/html"
    assert forbidden.status_code == 403 and b"family admin" in forbidden.data.lower()
    assert bad_csrf.status_code == 400 and bad_csrf.mimetype == "text/html"
    assert large.status_code == 413 and large.mimetype == "text/html"
    assert broken.status_code == 500 and b"internal details" not in broken.data
    assert api_missing.status_code == 404 and api_missing.is_json


def test_closed_signup_and_browser_rate_limit_use_friendly_error_template(tmp_path, monkeypatch):
    monkeypatch.setenv("ALLOW_SIGNUP", "false")
    app = create_app(str(tmp_path / "closed-html.db"))
    client = app.test_client()
    signup(client)
    closed = client.get("/signup", headers={"Accept": "text/html"})
    assert closed.status_code == 403 and b"Sign-ups are closed" in closed.data and b"Back to LittleBites" in closed.data

    app.config["LOGIN_RATE_LIMIT"] = (1, 60)
    guest = app.test_client()
    csrf = token(guest, "/login")
    form = {"username": "unknown", "password": "not-the-password", "csrf_token": csrf}
    assert guest.post("/login", data=form, headers={"Accept": "text/html"}).status_code == 401
    limited = guest.post("/login", data=form, headers={"Accept": "text/html"})
    assert limited.status_code == 429 and limited.mimetype == "text/html"




def test_rate_limit_is_shared_by_app_instances_using_same_database(tmp_path, monkeypatch):
    monkeypatch.setattr(app_module, "ask_llm", lambda *_: "A soft rice bowl could work.")
    path = str(tmp_path / "shared-limit.db")
    first_app = create_app(path)
    first_app.config["ASSISTANT_RATE_LIMIT"] = (1, 60)
    first = first_app.test_client()
    first.environ_base["REMOTE_ADDR"] = "198.51.100.23"
    assert post_json(first, "/api/assistant", {"question": "Give me an idea"}).status_code == 200

    second_app = create_app(path)
    second_app.config["ASSISTANT_RATE_LIMIT"] = (1, 60)
    second = second_app.test_client()
    second.environ_base["REMOTE_ADDR"] = "198.51.100.23"
    limited = post_json(second, "/api/assistant", {"question": "Another idea"})
    assert limited.status_code == 429
    assert int(limited.headers["Retry-After"]) >= 1

