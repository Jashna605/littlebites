const VERSION = "littlebites-v8";
const SHELL = [
  "/static/styles.css", "/static/app.js", "/static/pwa.js",
  "/static/manifest.webmanifest", "/static/favicon.svg",
  "/static/icons/icon-192.png", "/static/icons/icon-512.png", "/static/icons/maskable-512.png",
  "/static/fonts/Fredoka-Variable.woff2", "/static/fonts/Nunito-Variable.woff2",
  "/static/images/banana-oat-pancakes.webp", "/static/images/tomato-lentil-pasta.webp",
  "/static/images/tofu-rice-bowl.webp", "/static/images/baby-purees.webp",
  "/static/images/spinach-egg-muffins.webp", "/static/images/bean-quesadillas.webp",
  "/static/images/lentil-sweet-potato-soup.webp", "/static/images/berry-yogurt-bowl.webp",
  "/static/images/tofu-soba-noodles.webp", "/static/images/chickpea-couscous.webp",
];

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(VERSION).then(async (cache) => {
    await cache.addAll(SHELL);
    const guestHome = await fetch("/", { credentials: "omit", cache: "no-store" });
    if (guestHome.ok && !guestHome.headers.get("X-LittleBites-Authenticated")) await cache.put("/", guestHome);
  }).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((key) => key.startsWith("littlebites-") && key !== VERSION).map((key) => caches.delete(key)))).then(() => self.clients.claim()));
});

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== "GET" || url.origin !== self.location.origin) return;
  if (url.pathname === "/api/csrf" || url.pathname.startsWith("/login") || url.pathname.startsWith("/signup") || url.pathname.startsWith("/admin") || url.pathname.startsWith("/api/account") || url.pathname.startsWith("/api/profiles")) return;

  if (url.pathname === "/api/recipes" || url.pathname === "/api/recipes/new") {
    event.respondWith(fetch(request).then((response) => {
      if (response.ok && !response.headers.get("X-LittleBites-Authenticated")) {
        const copy = response.clone();
        caches.open(VERSION).then((cache) => cache.put(request, copy));
      }
      return response;
    }).catch(async () => (await caches.match(request)) || Response.error()));
    return;
  }

  if (request.mode === "navigate") {
    event.respondWith(fetch(request).then((response) => {
      if (response.ok && !response.headers.get("X-LittleBites-Authenticated")) {
        caches.open(VERSION).then((cache) => cache.put("/", response.clone()));
      }
      return response;
    }).catch(async () => (await caches.match("/")) || new Response("LittleBites is offline right now.", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } })));
    return;
  }

  event.respondWith(caches.match(request).then((cached) => cached || fetch(request)));
});
