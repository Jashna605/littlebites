(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const svgNS = "http://www.w3.org/2000/svg";
  const allergenNames = ["milk", "egg", "wheat", "peanut", "tree nuts", "soy", "fish", "shellfish", "sesame", "coconut"];
  const recipeEmojis = ["🥣", "🥗", "🍲", "🥞", "🍚", "🫓", "🍝", "🥕"];
  const badges = [
    { threshold: 1, icon: "🥄", title: "First Bite", detail: "Mark your first recipe as made." },
    { threshold: 3, icon: "🌈", title: "Curious Cook", detail: "Try 3 different recipes." },
    { threshold: 6, icon: "🧭", title: "Kitchen Explorer", detail: "Try 6 different recipes." },
  ];
  const inspirations = [
    "A new flavor can make an ordinary day feel like an adventure.",
    "Tiny helpers make happy memories in the kitchen.",
    "One simple meal can bring everyone to the table.",
    "Little bites, big smiles, and one less dinner decision.",
    "Try a familiar favorite with one colorful twist today.",
    "A cozy meal is a lovely way to slow down together.",
  ];
  const keys = {
    favorites: "littlebites-favorites", made: "littlebites-made-recipes",
    visits: "littlebites-app-visits", scroll: "littlebites-active-scroll-ms",
    session: "littlebites-visit-counted", lastInspiration: "littlebites-last-inspiration",
    lastFeatured: "littlebites-last-featured-recipe",
  };
  let signedIn = document.body.dataset.signedIn === "true";
  const state = {
    recipes: [], freshRecipes: [], visibleCount: 24,
    favorites: new Set((signedIn ? [] : readArray(keys.favorites)).map(Number)),
    made: new Set((signedIn ? [] : readArray(keys.made)).map(Number)),
    allergens: new Set(), favoritesOnly: false, selectedMeal: "",
    chatHistory: [], pendingChat: null, activeRecipe: null,
    cookingRecipe: null, cookingStep: 0, timerRemaining: 0, timerInterval: null,
    profiles: [], selectedProfileId: "", userState: null, comments: [], replyToComment: null,
  };
  let filterRefreshTimeout = null;
  let filterRequestId = 0;

  function apiHeaders(json = true) {
    const headers = { "X-CSRF-Token": document.querySelector('meta[name="csrf-token"]')?.content || "" };
    if (json) headers["Content-Type"] = "application/json";
    return headers;
  }

  function readArray(key) {
    try {
      const value = JSON.parse(localStorage.getItem(key) || "[]");
      return Array.isArray(value) ? value : [];
    } catch (_) { return []; }
  }

  function store(key, value) {
    try { localStorage.setItem(key, value); } catch (_) { /* Browser storage can be disabled. */ }
  }

  function node(tag, className = "", text = null) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== null) element.textContent = String(text);
    return element;
  }

  function svgNode(tag, attributes = {}) {
    const element = document.createElementNS(svgNS, tag);
    for (const [name, value] of Object.entries(attributes)) element.setAttribute(name, String(value));
    return element;
  }

  function replace(parent, ...children) { parent.replaceChildren(...children); }

  function listLines(value) {
    return value.split("\n").map((line) => line.trim()).filter(Boolean);
  }

  function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    return hours ? `${hours}:${String(minutes % 60).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}` : `${String(minutes).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  }

  function readNumber(key) {
    try {
      const value = Number(localStorage.getItem(key));
      return Number.isFinite(value) && value >= 0 ? value : 0;
    } catch (_) { return 0; }
  }

  function initActivity() {
    let visits = readNumber(keys.visits);
    try {
      if (!sessionStorage.getItem(keys.session)) {
        visits += 1;
        store(keys.visits, String(visits));
        sessionStorage.setItem(keys.session, "1");
      }
    } catch (_) { visits += 1; }
    $("visit-count").textContent = String(visits);
    let scrollMs = readNumber(keys.scroll);
    let lastScrollAt = 0;
    let lastTick = Date.now();
    let shownSecond = Math.floor(scrollMs / 1000);
    $("scroll-time").textContent = formatDuration(scrollMs);
    window.addEventListener("scroll", () => {
      lastScrollAt = Date.now();
      $("app-activity").classList.add("is-scrolling");
    }, { passive: true });
    document.addEventListener("visibilitychange", () => {
      lastTick = Date.now();
      if (document.hidden) {
        lastScrollAt = 0;
        $("app-activity").classList.remove("is-scrolling");
      }
    });
    window.setInterval(() => {
      const now = Date.now();
      const delta = Math.max(0, Math.min(now - lastTick, 1500));
      lastTick = now;
      const active = !document.hidden && lastScrollAt > 0 && now - lastScrollAt < 1400;
      $("app-activity").classList.toggle("is-scrolling", active);
      if (active) scrollMs += delta;
      const second = Math.floor(scrollMs / 1000);
      if (second !== shownSecond) {
        shownSecond = second;
        $("scroll-time").textContent = formatDuration(scrollMs);
        store(keys.scroll, String(scrollMs));
      }
    }, 250);
  }

  function chooseFresh(items, storageKey, getId) {
    if (!items.length) return null;
    let previous = null;
    try { previous = localStorage.getItem(storageKey); } catch (_) { /* Optional preference. */ }
    const options = items.length > 1 ? items.filter((item) => String(getId(item)) !== previous) : items;
    const result = options[Math.floor(Math.random() * options.length)];
    if (result) store(storageKey, String(getId(result)));
    return result;
  }

  function foodEmoji(recipe) {
    const name = String(recipe.n || "").toLowerCase();
    if (name.includes("pancake") || name.includes("chilla")) return "🥞";
    if (name.includes("soup") || name.includes("congee")) return "🍲";
    if (name.includes("pasta") || name.includes("noodle")) return "🍝";
    if (name.includes("arepa")) return "🫓";
    if (name.includes("rice")) return "🍚";
    if (name.includes("apple") || name.includes("avocado")) return "🥑";
    if (name.includes("chickpea") || name.includes("bean")) return "🥗";
    return recipeEmojis[(Number(recipe.id) || 0) % recipeEmojis.length];
  }

  function illustration(recipe, tone = 0) {
    const svg = svgNode("svg", { viewBox: "0 0 160 160", role: "img", "aria-label": `Illustration of ${recipe.n}`, class: `food-illustration tone-${tone}` });
    svg.append(svgNode("ellipse", { cx: 80, cy: 128, rx: 48, ry: 9, fill: "#6d73512e" }));
    svg.append(svgNode("circle", { cx: 80, cy: 77, r: 59, fill: "var(--dish-color)", stroke: "#a79d84", "stroke-width": 3 }));
    svg.append(svgNode("circle", { cx: 80, cy: 77, r: 45, fill: "#fffaf0", stroke: "#e1d6bd", "stroke-width": 3 }));
    svg.append(svgNode("ellipse", { cx: 61, cy: 59, rx: 15, ry: 9, fill: "var(--food-a)", transform: "rotate(-24 61 59)" }));
    svg.append(svgNode("ellipse", { cx: 101, cy: 62, rx: 13, ry: 8, fill: "var(--food-b)", transform: "rotate(22 101 62)" }));
    svg.append(svgNode("circle", { cx: 58, cy: 94, r: 7, fill: "var(--food-b)" }));
    svg.append(svgNode("circle", { cx: 103, cy: 97, r: 8, fill: "var(--food-a)" }));
    const fallback = svgNode("text", { x: 80, y: 88, "text-anchor": "middle", "font-size": 43, "aria-hidden": "true" });
    fallback.textContent = foodEmoji(recipe);
    svg.append(fallback);
    return svg;
  }

  const photoDescriptions = {
    "banana-oat-pancakes.webp": "Soft banana oat pancakes cut into strips with banana slices.",
    "tomato-lentil-pasta.webp": "A bowl of tomato lentil pasta with short shells and greens.",
    "tofu-rice-bowl.webp": "A rice bowl with tofu, peas, and diced carrots.",
    "baby-purees.webp": "Small bowls of smooth sweet potato and pea puree.",
    "spinach-egg-muffins.webp": "Soft spinach and egg muffins on a plate.",
    "bean-quesadillas.webp": "Bean and vegetable quesadilla wedges on a plate.",
    "lentil-sweet-potato-soup.webp": "A bowl of lentil and sweet potato soup.",
    "berry-yogurt-bowl.webp": "A bowl of berry yogurt with finely ground oats.",
    "tofu-soba-noodles.webp": "A warm bowl of soba noodles with tofu and vegetables.",
    "chickpea-couscous.webp": "A chickpea couscous bowl with cucumber, tomato, and herbs.",
  };

  function recipeArtwork(recipe, tone = 0) {
    if (!recipe.photo) return illustration(recipe, tone);
    const image = node("img", "recipe-photo");
    image.src = `/static/images/${encodeURIComponent(recipe.photo)}`;
    image.alt = photoDescriptions[recipe.photo] || `Example food photo for ${recipe.n}`;
    image.loading = "lazy";
    image.decoding = "async";
    image.addEventListener("error", () => image.replaceWith(illustration(recipe, tone)), { once: true });
    return image;
  }

  function tagNodes(recipe) {
    const items = (recipe.tags || []).slice(0, 5).map((tag) => {
      const isCaution = allergenNames.includes(tag) || String(tag).startsWith("honey:") || tag === "may contain gluten";
      return node("span", `tag ${isCaution ? "tag-alert" : ""}`, String(tag).replace(/\b\w/g, (letter) => letter.toUpperCase()));
    });
    items.push(node("small", "tag-note", "Ingredient-text clues only. Check labels and cross-contact."));
    return items;
  }

  function activeRecipes() {
    const term = $("search").value.trim().toLowerCase();
    const age = $("age").value === "" ? Infinity : Number($("age").value);
    const diet = $("diet").value;
    const pantry = $("pantry").value.toLowerCase().split(",").map((part) => part.trim()).filter(Boolean);
    const pantryOnly = $("pantry-only").checked;
    const matches = state.recipes.filter((recipe) => {
      const tags = recipe.tags || [];
      const searchText = [recipe.n, ...(recipe.ing || []), ...(recipe.steps || [])].join(" ").toLowerCase();
      if (Number(recipe.from) > age || (term && !searchText.includes(term))) return false;
      if (state.selectedMeal && !(recipe.meals || [recipe.meal]).includes(state.selectedMeal)) return false;
      if (state.favoritesOnly && !state.favorites.has(Number(recipe.id))) return false;
      if (diet && !tags.includes(diet)) return false;
      if ([...state.allergens].some((allergen) => tags.includes(allergen))) return false;
      const hasPantryMatch = pantry.some((part) => searchText.includes(part));
      return !(pantryOnly && pantry.length && !hasPantryMatch);
    });
    const minutes = (recipe) => {
      const match = String(recipe.time || "").match(/\d+/);
      return match ? Number(match[0]) : Number.MAX_SAFE_INTEGER;
    };
    if ($("sort").value === "quickest") matches.sort((a, b) => minutes(a) - minutes(b));
    else if ($("sort").value === "age") matches.sort((a, b) => Number(a.from) - Number(b.from));
    else matches.sort((a, b) => Number(b.id) - Number(a.id));
    return matches;
  }

  function recipeCard(recipe, index) {
    const id = Number(recipe.id);
    const isMade = state.made.has(id);
    const isFavorite = state.favorites.has(id);
    const card = node("article", "recipe-card");
    const visual = node("div", `recipe-visual tone-${index % 6}`);
    visual.append(recipeArtwork(recipe, index % 6));
    const body = node("div", "recipe-body");
    body.append(node("span", "recipe-kind", recipe.community ? (recipe.status === "approved" ? "Community share" : "Your share · pending review") : "Family favorite"));

    const titleRow = node("div", "recipe-title-row");
    titleRow.append(node("h3", "", recipe.n));
    const favorite = node("button", `heart-button ${isFavorite ? "is-saved" : ""}`, isFavorite ? "♥" : "♡");
    favorite.type = "button";
    favorite.dataset.favorite = String(id);
    favorite.setAttribute("aria-label", `${isFavorite ? "Remove from" : "Save to"} favorites`);
    favorite.setAttribute("aria-pressed", String(isFavorite));
    titleRow.append(favorite);

    const meta = node("div", "recipe-meta");
    meta.append(node("span", "", Number(recipe.from) === 0 ? "For ages under 12 months" : `For ages ${Number(recipe.from)}+ years`));
    if (recipe.meals?.length) meta.append(node("span", "", recipe.meals.join(" · ")));
    if (recipe.time) meta.append(node("span", "", recipe.time));
    const tags = node("div", "tag-list");
    tags.append(...tagNodes(recipe));
    const actions = node("div", "recipe-card-actions");
    const open = node("button", "small-action", "See recipe");
    open.type = "button";
    open.dataset.openRecipe = String(id);
    const cook = node("button", "small-action", "Start cooking");
    cook.type = "button";
    cook.dataset.startCooking = String(id);
    const made = node("button", `small-action ${isMade ? "made" : ""}`, madeLabel(isMade));
    made.type = "button";
    made.dataset.made = String(id);
    made.setAttribute("aria-pressed", String(isMade));
    actions.append(open, cook, made);
    body.append(titleRow, meta, tags, actions);
    card.append(visual, body);
    return card;
  }

  function emptyState(icon, title, description, actionText, actionName) {
    const wrapper = node("div", "empty-state");
    wrapper.append(node("span", "empty-icon", icon), node("strong", "", title), node("span", "", description));
    if (actionText) {
      const action = node("button", "button button-soft", actionText);
      action.type = "button";
      action.dataset.gridAction = actionName;
      wrapper.append(action);
    }
    return wrapper;
  }

  function showGridError(container, message, retryLabel) {
    const wrapper = node("div", "error-state");
    wrapper.append(node("span", "empty-icon", "☁"), node("strong", "", "Let’s try that again"), node("span", "", message));
    const retry = node("button", "button button-soft", retryLabel);
    retry.type = "button";
    retry.dataset.gridAction = "retry";
    wrapper.append(retry);
    replace(container, wrapper);
  }

  function updateFavoriteCount() { $("favorite-count").textContent = String(state.favorites.size); }

  function madeLabel(isMade) { return isMade ? "Made it ✓ (tap to undo)" : "I made this!"; }

  function refillProfileSelects() {
    ["profile-select", "chat-profile-select"].forEach((id) => {
      const select = $(id);
      if (!select) return;
      const first = node("option", "", id === "profile-select" ? "Choose a profile" : "No profile selected");
      first.value = "";
      select.replaceChildren(first);
      state.profiles.forEach((profile) => {
        const option = node("option", "", profile.name);
        option.value = String(profile.id);
        select.append(option);
      });
      select.value = state.selectedProfileId;
    });
  }

  function applyProfile(profileId) {
    state.selectedProfileId = profileId || "";
    const profile = state.profiles.find((item) => String(item.id) === state.selectedProfileId);
    refillProfileSelects();
    if (!profile) {
      $("age").value = "";
      $("diet").value = "";
      state.allergens.clear();
      $("profile-id").value = "";
      $("profile-name").value = "";
    } else {
      $("age").value = String(profile.age);
      $("diet").value = profile.diet;
      state.allergens = new Set(profile.allergens);
      $("profile-id").value = String(profile.id);
      $("profile-name").value = profile.name;
      $("profile-age").value = String(profile.age);
      $("profile-diet").value = profile.diet;
      document.querySelectorAll(".profile-allergens input").forEach((input) => { input.checked = state.allergens.has(input.value); });
    }
    document.querySelectorAll("[data-allergen]").forEach((chip) => chip.setAttribute("aria-pressed", String(state.allergens.has(chip.dataset.allergen))));
    if (profile) {
      $("helper-age").value = profile.age === 0 ? "Under 12 months" : String(profile.age) + " years";
      $("helper-diet").value = profile.diet;
      document.querySelectorAll(".chat-allergen-chips input").forEach((input) => { input.checked = profile.allergens.includes(input.value); });
    } else {
      $("helper-age").value = "";
      $("helper-diet").value = "";
      document.querySelectorAll(".chat-allergen-chips input").forEach((input) => { input.checked = false; });
    }
    $("profile-delete").hidden = !profile;
    scheduleRecipeRefresh();
  }

  async function loadAccountState() {
    if (!signedIn) return;
    try {
      let response = await fetch("/api/account/state", { cache: "no-store" });
      if (!response.ok) return;
      let account = await response.json();
      if (account.import_pending) {
        const localFavorites = readArray(keys.favorites).map(Number).filter(Number.isInteger);
        const localMade = readArray(keys.made).map(Number).filter(Number.isInteger);
        if (localFavorites.length || localMade.length) {
          const shouldImport = window.confirm("Import favorites and cooking badges saved in this browser to your account?");
          if (shouldImport) {
            response = await fetch("/api/account/import-local", { method: "POST", headers: apiHeaders(), body: JSON.stringify({ favorites: localFavorites, made: localMade }) });
          } else {
            response = await fetch("/api/account/skip-import", { method: "POST", headers: apiHeaders(), body: "{}" });
          }
        } else {
          response = await fetch("/api/account/skip-import", { method: "POST", headers: apiHeaders(), body: "{}" });
        }
        if (!response.ok) return;
        try { localStorage.removeItem(keys.favorites); localStorage.removeItem(keys.made); } catch (_) { /* Optional browser storage. */ }
        response = await fetch("/api/account/state", { cache: "no-store" });
        if (!response.ok) return;
        account = await response.json();
      }
      state.userState = account;
      state.favorites = new Set(account.favorites.map(Number));
      state.made = new Set(account.made.map(Number));
      state.profiles = account.profiles || [];
      refillProfileSelects();
      updateFavoriteCount();
      renderBadges();
    } catch (_) { /* Guest browsing and cached recipes remain available offline. */ }
  }

  async function saveProfile(event) {
    event.preventDefault();
    const allergens = [...document.querySelectorAll(".profile-allergens input:checked")].map((input) => input.value);
    const body = {
      id: $("profile-id").value ? Number($("profile-id").value) : null,
      name: $("profile-name").value.trim(), age: Number($("profile-age").value),
      diet: $("profile-diet").value, allergens,
    };
    const status = $("profile-status");
    try {
      const response = await fetch("/api/profiles", { method: "POST", headers: apiHeaders(), body: JSON.stringify(body) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not save this profile.");
      state.profiles = data.profiles;
      const saved = body.id ? state.profiles.find((profile) => profile.id === body.id) : state.profiles.reduce((latest, profile) => !latest || profile.id > latest.id ? profile : latest, null);
      applyProfile(saved ? String(saved.id) : "");
      status.textContent = "Profile saved. Its nickname stays in your LittleBites database.";
    } catch (error) { status.textContent = error.message; }
  }

  async function deleteProfile() {
    if (!state.selectedProfileId) return;
    try {
      const response = await fetch("/api/profiles/" + state.selectedProfileId, { method: "DELETE", headers: apiHeaders(false) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not delete this profile.");
      state.profiles = state.profiles.filter((profile) => String(profile.id) !== state.selectedProfileId);
      applyProfile("");
      $("profile-status").textContent = "Profile deleted.";
    } catch (error) { $("profile-status").textContent = error.message; }
  }

  function renderRecipes() {
    const recipes = activeRecipes();
    $("recipe-count").textContent = `${recipes.length} ${recipes.length === 1 ? "recipe" : "recipes"} found`;
    const grid = $("recipe-grid");
    if (!recipes.length) {
      const message = state.favoritesOnly ? "Save a recipe with its heart to see it here." : "Try another age or ingredient, or clear the filters.";
      replace(grid, emptyState("✿", state.favoritesOnly ? "No favorites saved yet" : "No bites match just yet", message,
        state.favoritesOnly ? "Show all recipes" : "Clear filters", state.favoritesOnly ? "all-recipes" : "clear"));
      $("load-more").hidden = true;
      return;
    }
    replace(grid, ...recipes.slice(0, state.visibleCount).map(recipeCard));
    const loadMore = $("load-more");
    loadMore.hidden = recipes.length <= state.visibleCount;
    if (!loadMore.hidden) loadMore.textContent = "Load " + Math.min(24, recipes.length - state.visibleCount) + " more recipes";
  }

  function renderFresh() {
    const grid = $("new-recipe-grid");
    const recipes = state.freshRecipes;
    $("new-status").textContent = `${recipes.length} new ${recipes.length === 1 ? "recipe" : "recipes"}`;
    if (!recipes.length) {
      const empty = emptyState("♡", "No new recipes yet", "Share a family favorite and it will show up here.");
      const share = node("a", "button button-soft", "Share a recipe");
      share.href = "#share";
      empty.append(share);
      replace(grid, empty);
      return;
    }
    const cards = recipes.map((recipe, index) => {
      const card = node("article", `fresh-card tone-${index % 6}`);
      const visual = node("div", "fresh-visual");
      visual.append(recipeArtwork(recipe, index % 6));
      card.append(visual);
      card.append(node("span", "recipe-kind", recipe.community ? (recipe.status === "approved" ? "Community share" : "Your share · pending review") : "New starter idea"));
      card.append(node("strong", "", recipe.n));
      const age = Number(recipe.from) === 0 ? "under 12 months" : `${Number(recipe.from)}+ years`;
      card.append(node("p", "", `For ages ${age}${recipe.time ? ` · ${recipe.time}` : ""}`));
      const open = node("button", "small-action", "Open this recipe");
      open.type = "button";
      open.dataset.openRecipe = String(recipe.id);
      card.append(open);
      return card;
    });
    replace(grid, ...cards);
  }

  function renderBadges(previousTotal = state.made.size) {
    const total = state.made.size;
    $("badge-summary").textContent = `${total} different ${total === 1 ? "recipe" : "recipes"} marked as made ${signedIn ? "in your account" : "on this device"}.`;
    const justEarned = total > previousTotal;
    const cards = badges.map((badge) => {
      const earned = total >= badge.threshold;
      const progress = Math.min(total, badge.threshold);
      const card = node("article", `badge-card ${earned ? "earned" : ""} ${earned && justEarned && previousTotal < badge.threshold ? "just-earned" : ""}`);
      card.append(node("span", "badge-icon", badge.icon));
      const copy = node("div", "badge-copy");
      copy.append(node("strong", "", badge.title));
      copy.append(node("small", "", earned ? "Badge earned!" : `${progress} of ${badge.threshold} recipes · ${badge.detail}`));
      const progressEl = node("progress", "badge-progress");
      progressEl.max = badge.threshold;
      progressEl.value = progress;
      progressEl.setAttribute("aria-label", `${progress} of ${badge.threshold} recipes toward ${badge.title}`);
      copy.append(progressEl);
      card.append(copy);
      return card;
    });
    replace($("badge-grid"), ...cards);
    if (justEarned) window.setTimeout(() => document.querySelectorAll(".badge-card.just-earned").forEach((badge) => badge.classList.remove("just-earned")), 700);
  }

  function openRecipe(recipeId) {
    const recipe = state.recipes.find((item) => Number(item.id) === Number(recipeId)) || state.freshRecipes.find((item) => Number(item.id) === Number(recipeId));
    if (!recipe) return;
    state.activeRecipe = recipe;
    $("dialog-title").textContent = recipe.n;
    $("dialog-type").textContent = recipe.community ? (recipe.status === "approved" ? "Shared by a family" : "Your recipe · awaiting review") : "LittleBites starter recipe";
    $("dialog-meta").textContent = `For ages ${Number(recipe.from) === 0 ? "under 12 months" : `${Number(recipe.from)}+ years`}${recipe.meals?.length ? ` · ${recipe.meals.join(", ")}` : ""}${recipe.time ? ` · ${recipe.time}` : ""}`;
    replace($("dialog-illustration"), recipeArtwork(recipe, Number(recipe.id) % 6));
    replace($("dialog-tags"), ...tagNodes(recipe));
    const ingredientNodes = (recipe.ing || []).map((item, index) => {
      const li = node("li");
      const label = node("label");
      const checkbox = node("input");
      checkbox.type = "checkbox";
      checkbox.dataset.ingredientCheck = String(index);
      label.append(checkbox, node("span", "", item));
      li.append(label);
      return li;
    });
    replace($("dialog-ingredients"), ...ingredientNodes);
    replace($("dialog-steps"), ...(recipe.steps || []).map((step) => node("li", "", step)));
    $("dialog-note").textContent = recipe.note || "Check every package, account for cross-contact, and choose a texture your child can manage.";
    const madeButton = $("dialog-made");
    const made = state.made.has(Number(recipe.id));
    madeButton.textContent = madeLabel(made);
    madeButton.setAttribute("aria-pressed", String(made));
    $("dialog-report-toggle").hidden = !recipe.community || !signedIn;
    $("dialog-edit").hidden = !recipe.can_edit;
    $("report-form").hidden = true;
    $("report-status").textContent = "";
    $("recipe-dialog").showModal();
    $("dialog-close").focus();
    loadComments(recipe.id);
  }

  function renderComments(comments) {
    state.comments = comments;
    const list = $("comments-list");
    if (!comments.length) {
      replace(list, node("p", "comment-empty", "No comments yet. Start with a kind kitchen tip."));
      return;
    }
    const children = new Map();
    comments.forEach((comment) => {
      const parent = comment.parent_id || 0;
      if (!children.has(parent)) children.set(parent, []);
      children.get(parent).push(comment);
    });
    const renderOne = (comment, nested = false) => {
      const article = node("article", `comment-card ${nested ? "comment-reply" : ""} ${comment.hidden ? "comment-hidden" : ""}`.trim());
      const meta = node("p", "comment-meta", `${comment.username}${comment.edited_at ? " · edited" : ""}${comment.hidden ? " · hidden pending review" : ""}`);
      const body = node("div", "comment-body");
      body.dataset.commentBody = String(comment.id);
      body.append(node("p", "", comment.body));
      article.append(meta, body);
      const actions = node("div", "comment-actions");
      if (comment.can_edit && !comment.hidden) {
        const edit = node("button", "text-button", "Edit");
        edit.type = "button";
        edit.dataset.commentEdit = String(comment.id);
        actions.append(edit);
      }
      if (signedIn && !comment.can_edit && !comment.hidden && !comment.has_reported) {
        const report = node("button", "text-button", "Report comment");
        report.type = "button";
        report.dataset.commentReport = String(comment.id);
        actions.append(report);
      }
      if (signedIn && !nested && !comment.hidden) {
        const reply = node("button", "text-button", "Reply");
        reply.type = "button";
        reply.dataset.commentReply = String(comment.id);
        actions.append(reply);
      }
      if (actions.childElementCount) article.append(actions);
      const replies = children.get(comment.id) || [];
      if (replies.length) {
        const group = node("div", "comment-replies");
        replies.forEach((reply) => group.append(renderOne(reply, true)));
        article.append(group);
      }
      return article;
    };
    replace(list, ...(children.get(0) || []).map((comment) => renderOne(comment)));
  }

  async function loadComments(recipeId) {
    const status = $("comments-status");
    if (!status) return;
    status.textContent = "Loading comments…";
    try {
      const response = await fetch(`/api/recipes/${recipeId}/comments`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Comments are unavailable right now.");
      if (!state.activeRecipe || Number(state.activeRecipe.id) !== Number(recipeId)) return;
      renderComments(data.comments || []);
      status.textContent = `${(data.comments || []).length} comments`;
    } catch (error) {
      status.textContent = error.message;
      replace($("comments-list"), node("p", "comment-empty", error.message));
    }
  }

  async function submitComment(event) {
    event.preventDefault();
    if (!state.activeRecipe) return;
    const body = $("comment-input").value.trim();
    const status = $("comments-status");
    status.textContent = "Posting comment…";
    try {
      const response = await fetch(`/api/recipes/${state.activeRecipe.id}/comments`, {
        method: "POST", headers: apiHeaders(),
        body: JSON.stringify({ body, parent_id: state.replyToComment }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not post that comment.");
      $("comment-input").value = "";
      state.replyToComment = null;
      $("comment-replying").hidden = true;
      $("comment-cancel-reply").hidden = true;
      await loadComments(state.activeRecipe.id);
    } catch (error) { status.textContent = error.message; }
  }

  async function handleCommentAction(event) {
    const reply = event.target.closest("[data-comment-reply]");
    if (reply) {
      const comment = state.comments.find((item) => item.id === Number(reply.dataset.commentReply));
      state.replyToComment = comment?.id || null;
      $("comment-replying").textContent = comment ? `Replying to ${comment.username}’s comment.` : "";
      $("comment-replying").hidden = !comment;
      $("comment-cancel-reply").hidden = !comment;
      $("comment-input").focus();
      return;
    }
    if (event.target.closest("#comment-cancel-reply")) {
      state.replyToComment = null;
      $("comment-replying").hidden = true;
      $("comment-cancel-reply").hidden = true;
      return;
    }
    const edit = event.target.closest("[data-comment-edit]");
    if (edit) {
      const id = Number(edit.dataset.commentEdit);
      const comment = state.comments.find((item) => item.id === id);
      const body = edit.closest(".comment-card").querySelector("[data-comment-body]");
      const input = node("textarea");
      input.maxLength = 500;
      input.value = comment?.body || "";
      input.setAttribute("aria-label", "Edit comment");
      const save = node("button", "small-action", "Save edit");
      save.type = "button";
      save.dataset.commentSave = String(id);
      const cancel = node("button", "text-button", "Cancel");
      cancel.type = "button";
      cancel.dataset.commentCancel = String(id);
      replace(body, input, save, cancel);
      input.focus();
      return;
    }
    const cancel = event.target.closest("[data-comment-cancel]");
    if (cancel) { await loadComments(state.activeRecipe.id); return; }
    const save = event.target.closest("[data-comment-save]");
    if (save) {
      const id = Number(save.dataset.commentSave);
      const input = save.closest(".comment-card").querySelector("textarea");
      try {
        const response = await fetch(`/api/comments/${id}`, { method: "PUT", headers: apiHeaders(), body: JSON.stringify({ body: input.value }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not edit the comment.");
        await loadComments(state.activeRecipe.id);
      } catch (error) { $("comments-status").textContent = error.message; }
      return;
    }
    const report = event.target.closest("[data-comment-report]");
    if (report) {
      try {
        const response = await fetch(`/api/comments/${report.dataset.commentReport}/report`, { method: "POST", headers: apiHeaders(), body: JSON.stringify({ reason: "" }) });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error || "Could not report the comment.");
        $("comments-status").textContent = "Thanks. The comment was sent to the admin for review.";
        await loadComments(state.activeRecipe.id);
      } catch (error) { $("comments-status").textContent = error.message; }
    }
  }

  async function setMade(recipeId) {
    const previous = state.made.size;
    const numericId = Number(recipeId);
    const active = !state.made.has(numericId);
    if (signedIn) {
      const response = await fetch("/api/account/made", { method: "POST", headers: apiHeaders(), body: JSON.stringify({ recipe_id: numericId, active }) });
      const data = await response.json();
      if (!response.ok) { window.alert(data.error || "Please sign in to save your cooking badge."); return; }
      state.made = new Set(data.items.map(Number));
    } else {
      if (active) state.made.add(numericId); else state.made.delete(numericId);
      store(keys.made, JSON.stringify([...state.made]));
    }
    renderBadges(previous);
    renderRecipes();
    if (state.activeRecipe && Number(state.activeRecipe.id) === Number(recipeId)) {
      const isMade = state.made.has(numericId);
      $("dialog-made").textContent = madeLabel(isMade);
      $("dialog-made").setAttribute("aria-pressed", String(isMade));
    }
  }

  async function toggleFavorite(recipeId) {
    const id = Number(recipeId);
    const active = !state.favorites.has(id);
    if (signedIn) {
      const response = await fetch("/api/account/favorites", { method: "POST", headers: apiHeaders(), body: JSON.stringify({ recipe_id: id, active }) });
      const data = await response.json();
      if (!response.ok) { window.alert(data.error || "Please sign in to sync favorites."); return; }
      state.favorites = new Set(data.items.map(Number));
    } else {
      if (active) state.favorites.add(id); else state.favorites.delete(id);
      store(keys.favorites, JSON.stringify([...state.favorites]));
    }
    updateFavoriteCount();
    renderRecipes();
  }

  function clearFilters() {
    $("search").value = "";
    $("age").value = "";
    $("diet").value = "";
    $("pantry").value = "";
    $("pantry-only").checked = false;
    $("sort").value = "newest";
    state.allergens.clear();
    state.selectedProfileId = "";
    state.selectedMeal = "";
    state.visibleCount = 24;
    refillProfileSelects();
    document.querySelectorAll("[data-allergen]").forEach((chip) => chip.setAttribute("aria-pressed", "false"));
    document.querySelectorAll("[data-meal-view]").forEach((button) => button.setAttribute("aria-pressed", String(button.dataset.mealView === "all")));
    scheduleRecipeRefresh();
  }

  function setMealView(meal) {
    state.selectedMeal = meal === "all" ? "" : meal;
    state.visibleCount = 24;
    document.querySelectorAll("[data-meal-view]").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.mealView === meal));
    });
    scheduleRecipeRefresh();
  }

  function setFavoriteView(view) {
    state.favoritesOnly = view === "favorites";
    document.querySelectorAll("[data-favorite-view]").forEach((button) => {
      button.setAttribute("aria-pressed", String(button.dataset.favoriteView === view));
    });
    renderRecipes();
  }

  function renderSkeletons() {
    replace($("recipe-grid"), ...Array.from({ length: 6 }, () => node("div", "skeleton")));
    replace($("new-recipe-grid"), ...Array.from({ length: 3 }, () => node("div", "skeleton skeleton-row")));
  }

  async function loadRecipes() {
    renderSkeletons();
    try {
      const [recipes, freshResponse] = await Promise.all([fetchAllRecipePages(), fetch("/api/recipes/new")]);
      if (!freshResponse.ok) throw new Error("The recipe shelf is taking a little break.");
      state.recipes = recipes;
      state.freshRecipes = await freshResponse.json();
      state.visibleCount = 24;
      const inspiration = chooseFresh(inspirations, keys.lastInspiration, (item) => item);
      if (inspiration) $("daily-inspiration").textContent = inspiration;
      const featured = chooseFresh(state.recipes, keys.lastFeatured, (item) => item.id);
      if (featured) {
        $("hero-food-name").textContent = featured.n;
        $("hero-food-emoji").textContent = foodEmoji(featured);
        $("featured-link").dataset.recipeId = featured.id;
      }
      updateFavoriteCount();
      renderRecipes();
      renderFresh();
    } catch (_) {
      $("recipe-count").textContent = "Recipes unavailable";
      $("new-status").textContent = "New recipes unavailable";
      showGridError($("recipe-grid"), "The recipe shelf is taking a little break.", "Try again");
      showGridError($("new-recipe-grid"), "We couldn’t find the newest ideas just now.", "Try again");
    }
  }

  function serverRecipeQuery(page) {
    const params = new URLSearchParams({ page: String(page), per_page: "60", sort: $("sort").value });
    const age = $("age").value;
    const query = $("search").value.trim();
    if (age) params.set("age", age);
    if (query) params.set("q", query);
    if (state.selectedMeal) params.set("meal", state.selectedMeal);
    return params;
  }

  async function fetchAllRecipePages() {
    const firstResponse = await fetch("/api/recipes?" + serverRecipeQuery(1));
    if (!firstResponse.ok) throw new Error("The recipe shelf is taking a little break.");
    const first = await firstResponse.json();
    const allItems = [...first.items];
    // Fetch every matching page before local tag filters run, so allergen and diet clues cover the full result set.
    for (let page = 2; page <= first.pages; page += 1) {
      const response = await fetch("/api/recipes?" + serverRecipeQuery(page));
      if (!response.ok) throw new Error("The recipe shelf is taking a little break.");
      const result = await response.json();
      allItems.push(...result.items);
    }
    return allItems;
  }

  function scheduleRecipeRefresh() {
    window.clearTimeout(filterRefreshTimeout);
    filterRefreshTimeout = window.setTimeout(async () => {
      const requestId = ++filterRequestId;
      $("recipe-count").textContent = "Updating recipes…";
      try {
        const recipes = await fetchAllRecipePages();
        if (requestId !== filterRequestId) return;
        state.recipes = recipes;
        state.visibleCount = 24;
        renderRecipes();
      } catch (_) {
        if (requestId === filterRequestId) showGridError($("recipe-grid"), "The recipe shelf is taking a little break.", "Try again");
      }
    }, 180);
  }

  function addChatMessage(role, content, extraClass = "") {
    const bubble = node("div", `chat-bubble ${role} ${extraClass}`.trim(), content);
    $("chat-log").append(bubble);
    $("chat-log").scrollTop = $("chat-log").scrollHeight;
    return bubble;
  }

  function selectedAllergies() {
    const chosen = [...document.querySelectorAll(".chat-allergen-chips:not(.profile-allergens) input:checked")].map((input) => input.value);
    const custom = $("helper-allergies").value.split(",").map((item) => item.trim()).filter(Boolean);
    return [...new Set([...chosen, ...custom])].join(", ");
  }

  async function sendChat(retry = false, suggestedMessage = "") {
    const status = $("assistant-status");
    if (!retry) {
      const question = (suggestedMessage || $("question").value).trim();
      if (!question) return;
      const payload = {
        message: question,
        history: state.chatHistory.slice(-10),
        age_range: $("helper-age").value,
        diet: $("helper-diet").value,
        allergies: selectedAllergies(),
        pantry: $("helper-pantry").value,
      };
      const chatProfile = $("chat-profile-select");
      if (chatProfile?.value) payload.profile_id = Number(chatProfile.value);
      state.pendingChat = { payload };
      addChatMessage("user", question);
      state.chatHistory.push({ role: "user", content: question });
      state.chatHistory = state.chatHistory.slice(-10);
      if (!suggestedMessage) $("question").value = "";
      updateChatCounter();
    }
    if (!state.pendingChat) return;
    const pending = state.pendingChat;
    const typing = addChatMessage("assistant", "Meal buddy is thinking…", "typing");
    status.textContent = "Waiting for a meal idea…";
    $("chat-retry").hidden = true;
    const submit = $("assistant-form").querySelector("button[type=submit]");
    submit.disabled = true;
    try {
      const response = await fetch("/api/chat", { method: "POST", headers: apiHeaders(), body: JSON.stringify(pending.payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "The meal buddy couldn’t answer.");
      typing.remove();
      addChatMessage("assistant", data.reply);
      state.chatHistory.push({ role: "assistant", content: data.reply });
      state.chatHistory = state.chatHistory.slice(-10);
      state.pendingChat = null;
      status.textContent = "Check ingredients and textures before cooking.";
    } catch (_) {
      typing.remove();
      status.textContent = "The meal buddy couldn’t answer just now. Check Ollama and try again.";
      $("chat-retry").hidden = false;
    } finally {
      submit.disabled = false;
    }
  }

  function updateChatCounter() { $("chat-counter").textContent = `${$("question").value.length} / 500`; }

  function timeMention(step) {
    const match = String(step).match(/\b(\d+)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)\b/i);
    if (!match) return 0;
    const unit = match[2].toLowerCase();
    const value = Number(match[1]);
    if (unit.startsWith("hour") || unit.startsWith("hr")) return value * 3600;
    if (unit.startsWith("sec")) return value;
    return value * 60;
  }

  function stopCookingTimer() {
    if (state.timerInterval) window.clearInterval(state.timerInterval);
    state.timerInterval = null;
    state.timerRemaining = 0;
  }

  function renderCookingStep() {
    const steps = state.cookingRecipe?.steps || [];
    if (!steps.length) return;
    stopCookingTimer();
    const lastIndex = steps.length - 1;
    const step = steps[state.cookingStep];
    $("cooking-title").textContent = state.cookingRecipe.n;
    $("cooking-progress-label").textContent = `Step ${state.cookingStep + 1} of ${steps.length}`;
    $("cooking-progress").max = steps.length;
    $("cooking-progress").value = state.cookingStep + 1;
    $("cooking-step").textContent = step;
    $("cooking-safety").textContent = state.cookingRecipe.note || "Check every ingredient label and choose a texture your child can manage.";
    $("cooking-safety").hidden = state.cookingStep !== 0;
    $("cooking-safety-final").textContent = state.cookingRecipe.note || "Check every ingredient label and choose a texture your child can manage.";
    $("cooking-safety-final").hidden = state.cookingStep !== lastIndex;
    const seconds = timeMention(step);
    $("cooking-timer").hidden = seconds === 0;
    $("timer-start").disabled = seconds === 0;
    $("timer-start").textContent = "Start timer";
    $("timer-message").textContent = seconds ? `Timer ready: ${formatDuration(seconds * 1000)}` : "";
    $("timer-start").dataset.seconds = String(seconds);
    $("cooking-back").disabled = state.cookingStep === 0;
    $("cooking-next").textContent = state.cookingStep === lastIndex ? "Finish cooking" : "Next step →";
    $("cooking-step").focus();
  }

  function startCooking(recipeId) {
    const recipe = state.recipes.find((item) => Number(item.id) === Number(recipeId)) || state.freshRecipes.find((item) => Number(item.id) === Number(recipeId));
    if (!recipe || !Array.isArray(recipe.steps) || !recipe.steps.length) return;
    state.cookingRecipe = recipe;
    state.cookingStep = 0;
    renderCookingStep();
    $("cooking-dialog").showModal();
  }

  function moveCookingStep(direction) {
    const count = state.cookingRecipe?.steps?.length || 0;
    if (!count) return;
    const next = state.cookingStep + direction;
    if (next < 0) return;
    if (next >= count) {
      stopCookingTimer();
      $("cooking-dialog").close();
      return;
    }
    state.cookingStep = next;
    renderCookingStep();
  }

  function toggleTimer() {
    if (state.timerInterval) window.clearInterval(state.timerInterval);
    state.timerInterval = null;
    state.timerRemaining = Number($("timer-start").dataset.seconds);
    if (!state.timerRemaining) return;
    const update = () => {
      $("timer-message").textContent = state.timerRemaining > 0 ? `Time left: ${formatDuration(state.timerRemaining * 1000)}` : "Timer is done! Check the food before serving.";
      if (state.timerRemaining <= 0) {
        window.clearInterval(state.timerInterval);
        state.timerInterval = null;
        $("timer-start").textContent = "Start again";
        return;
      }
      state.timerRemaining -= 1;
    };
    $("timer-start").textContent = "Restart timer";
    update();
    state.timerInterval = window.setInterval(update, 1000);
  }

  function shareValidation() {
    const name = $("recipe-name").value.trim();
    const ingredients = listLines($("recipe-ingredients").value);
    const steps = listLines($("recipe-steps").value);
    const time = $("recipe-time").value.trim();
    const errors = {
      name: !name ? "Add a recipe name." : name.length > 80 ? "Keep the name to 80 characters." : "",
      meal: !document.querySelector("[data-share-meal]:checked") ? "Choose at least one meal." : "",
      ingredients: !ingredients.length ? "Add at least one ingredient." : ingredients.length > 30 ? "Use 30 ingredients or fewer." : ingredients.some((item) => item.length > 120) ? "Keep each ingredient to 120 characters." : "",
      steps: !steps.length ? "Add at least one step." : steps.length > 20 ? "Use 20 steps or fewer." : steps.some((item) => item.length > 300) ? "Keep each step to 300 characters." : "",
      time: time && !/^\d{1,3}\s?(min|mins|minutes|hr|hrs|hours)$/i.test(time) ? "Use a time such as 20 min or 1 hour." : "",
    };
    $("name-error").textContent = errors.name;
    $("meal-error").textContent = errors.meal;
    $("ingredients-error").textContent = errors.ingredients;
    $("steps-error").textContent = errors.steps;
    $("time-error").textContent = errors.time;
    return !Object.values(errors).some(Boolean);
  }

  function updateSharePreview() {
    if (!$("recipe-form")) return;
    const name = $("recipe-name").value.trim();
    const ingredients = listLines($("recipe-ingredients").value);
    const steps = listLines($("recipe-steps").value);
    $("name-counter").textContent = `${$("recipe-name").value.length} / 80`;
    $("ingredients-counter").textContent = `${ingredients.length} / 30 ingredients`;
    $("steps-counter").textContent = `${steps.length} / 20 steps`;
    const preview = $("recipe-preview");
    const children = [node("strong", "", name || "Your recipe preview")];
    if (ingredients.length) {
      const list = node("ul");
      ingredients.forEach((item) => list.append(node("li", "", item)));
      children.push(list);
    }
    if (steps.length) {
      const list = node("ol");
      steps.forEach((step) => list.append(node("li", "", step)));
      children.push(list);
    }
    if (!ingredients.length && !steps.length) children.push(node("p", "", "Ingredients and steps will appear here as you type."));
    replace(preview, ...children);
  }

  async function shareRecipe(event) {
    event.preventDefault();
    const status = $("recipe-status");
    if (!shareValidation()) { status.textContent = "Please fix the highlighted fields."; return; }
    status.textContent = "Sharing your recipe…";
    const payload = {
      name: $("recipe-name").value.trim(), from: Number($("recipe-age").value),
      meals: [...document.querySelectorAll("[data-share-meal]:checked")].map((input) => input.value),
      time: $("recipe-time").value.trim(), ingredients: listLines($("recipe-ingredients").value),
      steps: listLines($("recipe-steps").value),
    };
    const editingId = $("recipe-form").dataset.editingId;
    const submit = $("recipe-form").querySelector("button[type=submit]");
    submit.disabled = true;
    try {
      const response = await fetch(editingId ? `/api/recipes/${editingId}` : "/api/recipes", { method: editingId ? "PUT" : "POST", headers: apiHeaders(), body: JSON.stringify(payload) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not share that recipe.");
      status.textContent = editingId ? "Recipe updated and returned to admin review." : "Recipe submitted! It will appear publicly after admin review.";
      $("recipe-preview").classList.remove("is-success");
      void $("recipe-preview").offsetWidth;
      $("recipe-preview").classList.add("is-success");
      event.target.reset();
      delete event.target.dataset.editingId;
      submit.textContent = "Share recipe ♡";
      updateSharePreview();
      await loadRecipes();
    } catch (error) { status.textContent = error.message; }
    finally { submit.disabled = false; }
  }

  function editActiveRecipe() {
    const recipe = state.activeRecipe;
    if (!recipe?.can_edit || !$("recipe-form")) return;
    const form = $("recipe-form");
    form.dataset.editingId = String(recipe.id);
    $("recipe-name").value = recipe.n;
    $("recipe-age").value = String(recipe.from);
    document.querySelectorAll("[data-share-meal]").forEach((input) => { input.checked = (recipe.meals || [recipe.meal || "dinner"]).includes(input.value); });
    $("recipe-time").value = recipe.time || "";
    $("recipe-ingredients").value = (recipe.ing || []).join("\n");
    $("recipe-steps").value = (recipe.steps || []).join("\n");
    form.querySelector("button[type=submit]").textContent = "Save recipe changes";
    $("recipe-status").textContent = "Edit your recipe below. Saving sends it back for admin review.";
    updateSharePreview();
    shareValidation();
    $("recipe-dialog").close();
    $("share").scrollIntoView({ behavior: "smooth", block: "start" });
    $("recipe-name").focus({ preventScroll: true });
  }

  async function reportRecipe(event) {
    event.preventDefault();
    if (!state.activeRecipe) return;
    const status = $("report-status");
    status.textContent = "Sending report…";
    try {
      const response = await fetch(`/api/recipes/${state.activeRecipe.id}/report`, {
        method: "POST", headers: apiHeaders(),
        body: JSON.stringify({ reason: $("report-reason").value.trim() }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Could not send the report.");
      status.textContent = "Thanks. This recipe has been sent for review.";
      $("report-form").reset();
    } catch (error) { status.textContent = error.message; }
  }

  function initNavigation() {
    const toggle = $("menu-toggle");
    const nav = $("site-nav");
    toggle.addEventListener("click", () => {
      const open = toggle.getAttribute("aria-expanded") !== "true";
      toggle.setAttribute("aria-expanded", String(open));
      nav.classList.toggle("is-open", open);
    });
    nav.addEventListener("click", (event) => {
      if (event.target.closest("a")) {
        nav.classList.remove("is-open");
        toggle.setAttribute("aria-expanded", "false");
      }
    });
    if ("IntersectionObserver" in window) {
      const links = [...nav.querySelectorAll("a")];
      const observer = new IntersectionObserver((entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
        if (!visible) return;
        links.forEach((link) => {
          if (link.hash === `#${visible.target.id}`) link.setAttribute("aria-current", "location");
          else link.removeAttribute("aria-current");
        });
      }, { rootMargin: "-18% 0px -68% 0px", threshold: [0, .1, .3, .6] });
      ["top", "recipes", "new-recipes", "kitchen-badges", "helper", "share"].forEach((id) => observer.observe($(id)));
    }
  }

  async function init() {
    initActivity();
    initNavigation();
    renderBadges();
    updateFavoriteCount();
    updateSharePreview();
    renderSkeletons();
    await loadAccountState();
    await loadRecipes();

    ["search", "age", "sort"].forEach((id) => $(id).addEventListener("input", scheduleRecipeRefresh));
    ["diet", "pantry", "pantry-only"].forEach((id) => $(id).addEventListener("input", renderRecipes));
    document.querySelectorAll("[data-allergen]").forEach((chip) => chip.addEventListener("click", () => {
      const allergen = chip.dataset.allergen;
      if (state.allergens.has(allergen)) state.allergens.delete(allergen);
      else state.allergens.add(allergen);
      chip.setAttribute("aria-pressed", String(state.allergens.has(allergen)));
      renderRecipes();
    }));
    document.querySelectorAll("[data-favorite-view]").forEach((button) => button.addEventListener("click", () => setFavoriteView(button.dataset.favoriteView)));
    document.querySelectorAll("[data-meal-view]").forEach((button) => button.addEventListener("click", () => setMealView(button.dataset.mealView)));
    $("clear-filters").addEventListener("click", clearFilters);
    $("load-more").addEventListener("click", () => { state.visibleCount += 24; renderRecipes(); });
    $("surprise").addEventListener("click", () => {
      const recipes = activeRecipes();
      if (recipes.length) openRecipe(recipes[Math.floor(Math.random() * recipes.length)].id);
    });
    $("featured-link").addEventListener("click", () => openRecipe($("featured-link").dataset.recipeId));
    document.body.addEventListener("click", (event) => {
      const openButton = event.target.closest("[data-open-recipe]");
      if (openButton) openRecipe(openButton.dataset.openRecipe);
      const cookButton = event.target.closest("[data-start-cooking]");
      if (cookButton) startCooking(cookButton.dataset.startCooking);
      const favoriteButton = event.target.closest("[data-favorite]");
      if (favoriteButton) toggleFavorite(favoriteButton.dataset.favorite).catch(() => {});
      const madeButton = event.target.closest("[data-made]");
      if (madeButton) setMade(madeButton.dataset.made).catch(() => {});
      const actionButton = event.target.closest("[data-grid-action]");
      if (actionButton?.dataset.gridAction === "clear") clearFilters();
      if (actionButton?.dataset.gridAction === "retry") loadRecipes();
      if (actionButton?.dataset.gridAction === "all-recipes") setFavoriteView("all");
      const suggestion = event.target.closest("[data-chat-suggestion]");
      if (suggestion) sendChat(false, suggestion.dataset.chatSuggestion);
    });

    $("dialog-close").addEventListener("click", () => $("recipe-dialog").close());
    $("recipe-dialog").addEventListener("click", (event) => { if (event.target === $("recipe-dialog")) $("recipe-dialog").close(); });
    $("dialog-made").addEventListener("click", () => { if (state.activeRecipe) setMade(state.activeRecipe.id).catch(() => {}); });
    $("dialog-cook").addEventListener("click", () => {
      if (state.activeRecipe) {
        const recipe = state.activeRecipe;
        $("recipe-dialog").close();
        startCooking(recipe.id);
      }
    });
    $("dialog-print").addEventListener("click", () => window.print());
    $("dialog-edit").addEventListener("click", editActiveRecipe);
    $("dialog-report-toggle").addEventListener("click", () => { $("report-form").hidden = !$("report-form").hidden; });
    $("report-form").addEventListener("submit", reportRecipe);
    $("comments-list").addEventListener("click", handleCommentAction);
    if ($("comment-form")) $("comment-form").addEventListener("submit", submitComment);

    $("cooking-close").addEventListener("click", () => $("cooking-dialog").close());
    $("cooking-dialog").addEventListener("close", stopCookingTimer);
    $("cooking-back").addEventListener("click", () => moveCookingStep(-1));
    $("cooking-next").addEventListener("click", () => moveCookingStep(1));
    $("timer-start").addEventListener("click", toggleTimer);
    document.addEventListener("keydown", (event) => {
      if (!$("cooking-dialog").open || event.altKey || event.ctrlKey || event.metaKey) return;
      if (event.key === "ArrowRight") { event.preventDefault(); moveCookingStep(1); }
      if (event.key === "ArrowLeft") { event.preventDefault(); moveCookingStep(-1); }
    });

    $("assistant-form").addEventListener("submit", (event) => { event.preventDefault(); sendChat(); });
    $("chat-retry").addEventListener("click", () => sendChat(true));
    $("question").addEventListener("input", updateChatCounter);
    if ($("recipe-form")) {
      $("recipe-form").addEventListener("submit", shareRecipe);
      document.querySelectorAll("[data-share-meal]").forEach((input) => input.addEventListener("change", shareValidation));
      ["recipe-name", "recipe-time", "recipe-ingredients", "recipe-steps"].forEach((id) => {
        $(id).addEventListener("input", () => { updateSharePreview(); shareValidation(); });
      });
    }
    if ($("profile-select")) {
      $("profile-select").addEventListener("change", () => applyProfile($("profile-select").value));
      $("chat-profile-select").addEventListener("change", () => applyProfile($("chat-profile-select").value));
      $("profile-manage-toggle").addEventListener("click", () => {
        const form = $("profile-form");
        form.hidden = !form.hidden;
        $("profile-manage-toggle").setAttribute("aria-expanded", String(!form.hidden));
      });
      $("profile-form").addEventListener("submit", saveProfile);
      $("profile-new").addEventListener("click", () => {
        $("profile-id").value = "";
        $("profile-name").value = "";
        $("profile-delete").hidden = true;
        $("profile-name").focus();
      });
      $("profile-delete").addEventListener("click", deleteProfile);
    }
  }

  document.addEventListener("DOMContentLoaded", init);
})();
