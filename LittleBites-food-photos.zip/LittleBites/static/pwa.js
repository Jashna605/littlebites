(() => {
  "use strict";
  const notice = document.getElementById("offline-notice");
  function updateConnection() {
    if (notice) notice.hidden = navigator.onLine;
  }
  function refreshCsrf() {
    if (!navigator.onLine) return;
    fetch("/api/csrf", { cache: "no-store" }).then((response) => response.ok ? response.json() : null).then((data) => {
      const meta = document.querySelector('meta[name="csrf-token"]');
      if (data && meta) meta.content = data.csrf_token;
    }).catch(() => {});
  }
  window.addEventListener("online", () => { updateConnection(); refreshCsrf(); });
  window.addEventListener("offline", updateConnection);
  updateConnection();
  refreshCsrf();
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js", { scope: "/" }).catch(() => {}));
  }
})();
